# Compass Case View

Used to display salesforce and archived cases.

**Prod Url:** https://compasscaseview.azurewebsites.net/home

**UAT Url:** https://compasscaseview-uat.azurewebsites.net/home

**Dev Url:** https://compasscaseview-dev.azurewebsites.net/home

***Branch Description:***

**feature-deployment:** Used to deploy in dev slot

**develop:** Also deploy in dev slot with sonarqube validation

**release-uat:** Used for uat slot deployment

**master:** Used for production deployment

Flow should be feature-deployment->develop->release-uat->master
