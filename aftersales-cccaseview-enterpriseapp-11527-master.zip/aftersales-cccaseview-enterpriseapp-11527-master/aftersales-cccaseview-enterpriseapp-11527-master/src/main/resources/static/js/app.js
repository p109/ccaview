let isLoading=false;
let numberOfSections=0;

function progressBarAnimation(){
	if(isLoading===true){
	 setTimeout(function () {
		 if(   parseFloat($('#progressBar').css('margin-left')) <screen.width ){
		 	$('#progressBar').css('margin-left', '+=1%'); 
		 	progressBarAnimation();
		 }
		 else{
			 $('#progressBar').css('margin-left', '0%'); 
			 	progressBarAnimation();
		 }
	  }, 10);
	}
}

function startLoadingAnimation(){
	isLoading =true;
	$('#loadingDiv').show();
	progressBarAnimation();
}

function endLoadingAnimation(){
	isLoading =false;
	$('#loadingDiv').hide();
	$('#progressBar').css('margin-left', '0%'); 
	
}
function ajaxCallToFetchData(url, method, inputData, fun) {

	startLoadingAnimation();
	var response = $.ajax({
		type : method,
		contentType : "application/json",
		url : url,
		data : JSON.stringify(inputData),
		dataType : 'json',
		cache : false,
		timeout : 600000,
		success : function(data) {
			endLoadingAnimation();
			fun(data);
		},
		error : function(e) {
			endLoadingAnimation();
			if(0 === e.readyState){
				$(document).trigger("add-alerts", [ {
					message : 'Session has expired. Please login in a new window to continue',
					priority : 'danger'
				} ]);
			} else {
				$(document).trigger("add-alerts", [ {
					message : e.responseText,
					priority : 'danger'
				} ]);
			}
		}
	});
	return response;
}

$(document)
		.ready(
				function() {

					$("#caseDetails")
							.DataTable(
									{
										iDisplayLength : 10,
										scrollCollapse : true,
										bAutoWidth : false,
										sPaginationType : "full_numbers",
										order : [ [ 0, "asc" ] ],
										bProcessing : false,
										destroy : true,
										paging : true,
										aoColumns : [
												{
													aTargets : [ 0 ],
													mDataProp : "caseNumber",
													sType : "html",
													sClass : "left",
													sWidth : "10%",
													fnCreatedCell : function(p,
															e, s) {//changed for sonar fixes
														
														//t1862nm start
														if((s.type.toLowerCase() === 'legal' || s.owner.toLowerCase() === 'legal queue') && userRole !==  legalRoleDisplay){
															$(p).html(s.caseNumber);
															}else{
																$(p).html("<a href='#'>"+ s.caseNumber+ "</a>");
																$(p).on("click",function() {//changed for sonar fixes
																	clickEventOnCase(s);
																	var t = $("#caseDetails")
																		.DataTable();
																		t.cells(".selected")
																		.nodes()
																		.to$()
																		.removeClass("selected");
																		$(this).addClass("selected");
																			return false
																		});
															}
														//t1862nm end
													
													}
												},
												{
													aTargets : [ 1 ],
													mDataProp : "vin",
													sClass : "center"
												},
												{
													aTargets : [ 2 ],
													mDataProp : "lob",
													sClass : "center"
												},
												{
													aTargets : [ 3 ],
													mDataProp : "creatDate",
													sClass : "center"
												},
												{
													aTargets : [ 4 ],
													mDataProp : "callerName",
													sClass : "center"
												},
												{
													aTargets : [ 5 ],
													mDataProp : "subject",
													sClass : "center"
												},
												{
													aTargets : [ 6 ],
													mDataProp : "lastModifiedDate",
													sClass : "center"
												},
												{
													aTargets : [ 7 ],
													mDataProp : "status",
													sClass : "center"
												},
												{
													aTargets : [ 8 ],
													mDataProp : "ecciCaseNumber",
													sClass : "center"
												}, {
													aTargets : [ 9 ],
													mDataProp : "type",
													sClass : "center-checkBox",
													fnCreatedCell : function(p,e, s){//changed for sonar fixes
														
														if(s.type.toLowerCase()==='legal' || s.owner.toLowerCase() === 'legal queue'){
															$(p).html('<input type="checkbox" checked="true" disabled="true"></input>');
														}
														else{
															$(p).html('<input type="checkbox" disabled="true"></input>');
														}
													}
														
												} ],
										sDom : "<'dt-toolbar'<'col-xs-12 col-sm-6'f><'col-sm-6 col-xs-6 hidden-xs'lT>r>t<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-sm-6 col-xs-12'p>>",

									});
					$("#btnResetCaseDetails").on(
							"click",
							function() {
								
								$('#vin').val("");
								
								var caseTable = $("#caseDetails").DataTable();
								caseTable.clear().draw();
								$(document).trigger("clear-alerts");
								$("#content").find(".has-error").removeClass(
										"has-error");
								$('input[type=search]').val("");
							});
					//..ENHC0127020 Added
					
					$("#btnResetCaseNumDetails").on(
							"click",
							function() {
								
								$('#caseNumber').val("");
								$(document).trigger("clear-alerts");
								$("#content").find(".has-error").removeClass(
										"has-error");
								$('input[type=search]').val("");
							});
					
					
					//..ENHC0127020 ended

					$("#btnSearchCaseDetails")
							.on(
									"click",
									function() {
										//..ENHC0127020 added
											$('#caseNumber').val("");
										//..ENHC0127020 Ended
						var caseDataTable = $('#caseDetails').DataTable();//changed for sonar
						caseDataTable.search( '' ).columns().search( '' ).draw();//changed for sonar
										var vin =$('#vin');
										if (validateInput(vin)) {
											var inputFilterBean = {}
											inputFilterBean["value"] = $("#vin")
													.val();
											inputFilterBean["name"] = "ASSET.CC_VIN__c";
											inputFilterBean["operator"] = "=";
											inputFilterBean["isNumeric"] = false;
											ajaxCallToFetchData(
													"getCaseDetailsOnVin",
													"POST",
													inputFilterBean,
													function(successData) {
														var caseTable = $(
																"#caseDetails")
																.DataTable();
														caseTable.clear()
																.draw();
														caseTable.rows
																.add(
																		successData.caseViewOutputs)
																.draw();
													});
										} else {
											var caseTable = $(
											"#caseDetails")
											.DataTable();
											caseTable.clear()
											.draw();
										}
										
										return false;
									});
					
					//..ENHC0127020 added
					$("#btnSearchCaseNumDetails").on("click", function(){
						$('#vin').val("");
						
						var caseTable = $("#caseDetails").DataTable();
						caseTable.clear().draw();
						if(validateCaseNumber($("#caseNumber"))){
							var caseNum = $("#caseNumber").val();
							getCaseDetailsOnNumber(caseNum);
						}
					});
					//..ENHC0127020 ended
					$('#loadingDiv').hide();
					$("#modalExpandAllSections").on("click",function() {
							for(let i=0 ;i <numberOfSections ; i++){
								if(!$('#panelContent'+i).hasClass('in')){//t1862nm
									$('#panelContent'+i).collapse('show');
								}
							}
					});
					$("#modalCollapseAllSections").on("click",function() {
						for(let i=0 ;i <numberOfSections ; i++){
							$('#panelContent'+i).collapse('hide');
						}
					});
					//t1862nm start
					  $("body").on("keydown", function(f) {
						  var key = f.which;
						  if(key === 13){//changed for sonar
							  //..ENHC0127020 added
							  var caseNumberInput = $("#caseNumber");
							  var vinInput = $("#vin");
							  	if(caseNumberInput.val() && vinInput.val()){
							  		displayMsg("show", "Please search either using VIN or Case Number",
											[vinInput, caseNumberInput],'danger');
							  	}else if(vinInput.val()){
							  		$("#btnSearchCaseDetails").trigger('click');
							  		
							  	}else if(caseNumberInput.val()){
							  		$("#btnSearchCaseNumDetails").trigger('click');
							  		
							  	}else{
							  		displayMsg("show", "Please enter either VIN or Case Number",[vinInput,caseNumberInput],'danger');
							  	}
							  //..ENHC0127020 ended
							  
							  //..existing
							  //$('#btnSearchCaseDetails').trigger('click');
						    return false;  
						  }
						});   
					//t1862nm end
				});


function clickEventOnCase(data) {
	
	if(data.lob ===null || data.lob ===''){
		displayMsg("show", "The selected case has no LOB value, Please contact system administrator.",null,'danger');
		return;
	}

	
	var inputFilterBean = {}
	inputFilterBean["value"] = data.caseNumber;
	inputFilterBean["lob"] = data.lob;
	inputFilterBean["name"] = "CASE.CASENUMBER";
	inputFilterBean["operator"] = "=";
	inputFilterBean["isNumeric"] = false;
	inputFilterBean["source"] = data.source;
	
	$("#content").find(".has-error").removeClass("has-error");
	$(document).trigger("clear-alerts");
	ajaxCallToFetchData("getCaseDetailsOnCaseNumber", "POST", inputFilterBean,
			function(q) {
				var successData = q.caseViewDetailsBeansMap;
				if(null != successData){
					generateDynamicTemplate(successData);
					$('#myModal').show();
					$('.modal-body').scrollTop(0);
				} else {
					$(document).trigger("add-alerts", [ {
						message : 'Error occurred in fetching additional case details. Please contact System Administrator.',
						priority : 'danger'
					} ]);
				}		
			})
}

//ENHC0127020 Added
function getCaseDetailsOnNumber(caseNumber) {
	var inputFilterBean = {};
	inputFilterBean["value"] = caseNumber;
	inputFilterBean["name"] = "CASE.CASENUMBER";
	inputFilterBean["isNumeric"] = false;
	
	$("#content").find(".has-error").removeClass("has-error");
	$(document).trigger("clear-alerts");
	ajaxCallToFetchData("getCaseDetailsOnCaseSearch", "POST", inputFilterBean,
			function(q) {
				var successData = q.caseViewDetailsBeansMap;
				if(null != successData){
					generateDynamicTemplate(successData);
					$('#myModal').show();
					$('.modal-body').scrollTop(0);
				} else {
					$(document).trigger("add-alerts", [ {
						message : 'Error occurred in fetching additional case details. Please contact System Administrator.',
						priority : 'danger'
					} ]);
				}		
			})
}
 
 //..ENHC0127020 Ended

function validateInput(vinInput) {
	var vin = vinInput.val().trim();
	if (vin.length !== 8 && vin.length !== 17) {//changed for sonar
		displayMsg("show", "Please enter last 8 digit or full 17 digit VIN",
				vinInput,'danger');
		return false;
	} else {
		displayMsg("hide", "", vinInput,'');
		return true;
	}
}

//..ENHC0127020 Added
function validateCaseNumber(caseNumberInput){
	var caseNumber = caseNumberInput.val().trim();
	var validation = /^[0-9]*$/;
	if(!validation.test(caseNumber) || caseNumber.length===0){
		displayMsg("show", "Please enter a valid case number",
				caseNumberInput, "danger");
		return false;
	} else{
		displayMsg("hide", "", caseNumberInput, '');
		return true;
	}
}
//..ENHC0127020 Ended

function displayMsg(type, msg,vinInput,priorityStr) {
	if (type === "show") {//changed for sonar
		$(document).trigger("add-alerts", [ {
			message : msg,
			priority : priorityStr
		} ]);
		if(	vinInput !== null){
			//..ENHC0127020 added for multiple selector in the vin Input
			if(Array.isArray(vinInput)){
				for(var input in vinInput){
					if(vinInput.hasOwnProperty(input)){
					vinInput[input].parent().addClass("has-error");
					}
				}
			}
			else{
				vinInput.parent().addClass("has-error");
			}
			//..ENHC0127020 ended
			
			//..existing code commented
			//vinInput.parent().addClass("has-error");
		}
	} else {
		$(document).trigger("clear-alerts");
		$("#content").find(".has-error").removeClass("has-error");
	}
}


/*..ENHC0127020 added changes needed for adding the mileage  into the vehicle detail section..*/

function updateJsonForTable(json){

	for(var i in json){
		if(json.hasOwnProperty(i)){
			var data = json[i];
			var type =  data[0].type;

			if(type === "TABLE"){
				for(var j =1; j<data.length; j++){
					json[i][j].type = type;
				}
			}
		}
	}

}


function swap(arr, first, second){
		var temp = arr[first];
		arr[first] = arr[second];
		arr[second] = temp;

}
function swapper(arr, colList, offset, sortindex, position){
		var pos = position - sortindex;
		for(var col in colList){
			//..ENHC0127020 sonar fix
			if(colList.hasOwnProperty(col)){
				swap(arr, (colList[col]-1)*offset+pos, (colList[col]-1)*offset+pos+1);
			}
			
		}
	}   

function sorter(jsonInput, attributeList){
	var offset;
	var temp;
	for(var i in attributeList){

		if(attributeList.hasOwnProperty(i)&&jsonInput[i]!==undefined){
			temp = jsonInput[i];

			var noOfCols = temp[temp.length-1].attributeNumber;
			offset = temp.length/temp[temp.length-1].attributeNumber;


			var colList={};
			for(var j=0;j<noOfCols;j++){

				colList[temp[j*offset].attribute] = temp[j*offset].attributeNumber;
			}
			var sortindex = (colList[attributeList[i]]-1)*(offset);
			
			for (var k=sortindex;k<sortindex+offset;k++){
				for(var l=sortindex;l<sortindex+offset-(k-sortindex)-1;l++){
					
					if(temp[l].value<temp[l+1].value){
						swapper(temp, colList, offset, sortindex, l);
					}


				}
			}

			jsonInput[i] = temp;
		}
	}
}
/*..ENHC0127020 ended ..*/
function generateDynamicTemplate(json) {
	var html3 = ' <div class="panel panel-primary case-view-panel" id="subPanel';
	var html5 = ' <div class="panel-heading">';
	var html6 = ' <a data-target="#panelContent';
	var html7 = ' data-parent="#subPanel';
	var html8 = ' data-toggle="collapse"><span class="pull-right"><i class="panelIcon';
	var html9 = ' fa fa-arrow-up"></i></span> </a>';
	var html10 = '</div>';
	var html11 = '<div class="panel-collapse collapse in" id="panelContent';
	var html12 = '<div class="panel-body">';
	var html13 = '</div> </div> </div>';
	var finalHtml = "";
	
	/*..ENHC0127020 added ..*/
	var attributeListS = {
			"Case Comment":"CaseComments.CreatedDate",
			"Attachment": "Fax_Scan_Documents__r.CreatedDate",
			"Emails":"EmailMessages.MessageDate"
	}
	var attributeListR = {
			"Case Comment": "CASE_COMMENT.CREATEDDATE",
			"Attachment" : "DOCUMENT.CREATEDDATE",
			"Emails":"EMAIL_MESSAGE.MESSAGEDATE"
	}

	updateJsonForTable(json);
	if(json[Object.keys(json)[0]][0].source==='R'){
		sorter(json, attributeListR);
	} else{
		sorter(json, attributeListS)
	}
	

		
	/*..ENHC0127020 ended ..*/
	var j=0;
	$.each(json, function (key, data) {
	     finalHtml +=html3 + j + '">';
	     finalHtml += html5 + key;
	     finalHtml +=html6 + j+'"' + html7 + j + '"' + html8 + j;
	     finalHtml +=html9 + html10 + html11 + j + '">' + html12 ;
	     
	     let isTable=false;
	     var table_body = '<table border="1" id="'+key.trim().replace(' ','')+'" class="table table-bordered"><tr>';
			  var indexVal=1;
			  var dataLength=data.length; 
			  const numberOfAttachments =dataLength/2;
	    $.each(data, function (index, dataAttribute) {
	    	if(dataAttribute.type.trim()==='OBJECT' || dataAttribute.type.trim()==='LIST'){	    		 
		    	if(indexVal % 2 === 0 ){
			        table_body +='<td style="width: 20%;">';
		             if(dataAttribute.value!==null){
		            	  table_body +='<span class="display-attribute">'+dataAttribute.displayAttribute+'</span>';
		             }else{
		            	 table_body +='<span class="display-value"></span>';
		             }
		            table_body +='</td>';
		            
		            table_body +='<td style="width: 30%;">';
		             if(dataAttribute.value!==null){
		            	 table_body +='<span class="display-value">'+dataAttribute.value+'</span>';
		             }else{
		            	 table_body +='<span class="display-value"></span>';
		             }
		            table_body +='</td>';
		            table_body +='</tr>';
		            if(indexVal<dataLength){
		            	table_body +='<tr>';
		            }
		          
		    	}else{
	    		 table_body +='<td style="width: 20%;">';
	             table_body +='<span class="display-attribute">'+dataAttribute.displayAttribute+'</span>';
	             table_body +='</td>';
	             
	             table_body +='<td style="width: 30%;">';
	             if(dataAttribute.value!==null){
	            	 table_body +='<span class="display-value">'+dataAttribute.value+'</span>';
	             }else{
	            	 table_body +='<span class="display-value"></span>';
	             }
	             table_body +='</td>';
		    	}
		    	indexVal++;
	    	} else if(dataAttribute.type.trim()==='ATTACHMENT'){
	    		if(index<numberOfAttachments ){
	    			table_body+= '<td>' +data[index].value;
		    		table_body+='<button class="btn" style="margin-left: 50px" onclick="getAttachemnt(\''+data[index+numberOfAttachments].value +'\')">';
	    			table_body+='<span class="fa fa-paperclip fa-lg"></span></button>'+ '</span></td></tr>';
	    			
	    		}
    			
	    	}
	    	else if(dataAttribute.type.trim()==='TABLE'){
	    		isTable=true;
	    			const thElements= table_body.split('<th class="table-element">');
	    			if(thElements[thElements.length-1]!== dataAttribute.displayAttribute + '</th>'){
	    				table_body+='<th class="table-element">' + dataAttribute.displayAttribute + '</th>';
	    			}
	    	}
	    });
	    if(isTable){
			const tableData = buildTableData(data);	// changed for sonar fixes
			table_body+=tableData;
		}
	    table_body+='</table>';
	    finalHtml+=table_body+html13;
	    j++;
	});
	numberOfSections=j;
	//..ENHC0127020 added
	
	//..ENHC0127020 ended
	$('#mainPanelBody').html(finalHtml);
}


function getAttachemnt(pid){
	var $preparingFileModal = $("#preparing-file-modal");
	 
    $preparingFileModal.dialog({ modal: true });
	$.fileDownload('/getCaseDetailsAttachment?pid='+ pid,{	
		successCallback: function () {//changed for sonar fixes

            $preparingFileModal.dialog('close');
        },
        failCallback: function () {//changed for sonar fixes

            $preparingFileModal.dialog('close');
            $("#error-modal").dialog({ modal: true });
        }
	});
}

function buildTableData(data){//changed for sonar fixes
	    let tableData='';
		let numOfCols = 0;
		for (var i = 0; i < data.length; i++) {
			 const sectionElement = data[i];
				 if(sectionElement.type.trim()==='TABLE' && sectionElement.attributeNumber > numOfCols){//changed for sonar fixes
						 numOfCols = sectionElement.attributeNumber;
					 }
		  }
		const numOfRows = data.length / numOfCols;
		
	   for(let i=0 ; i < numOfRows ; i++){
		  tableData+= '<tr>';
		   for (var j = i; j <  data.length; j+=numOfRows) {
		   		const dataAttribute = data[j];
		   	 if(dataAttribute.value!==null){
				//..ENHC0127020 added in order to set attachment section in table only	
		   		 //This condition will set the table column with name download to the paperclip 
		   		 // So always make sure if wanted to display paperclip then to set the attribute name as download
		   		 if(dataAttribute.displayAttribute==='Download'){
						tableData+= '<td>'
			    		tableData+='<button class="btn" style="margin-left: 50px" onclick="getAttachemnt(\''+dataAttribute.value +'\')">';
		    			tableData+='<span class="fa fa-paperclip fa-lg"></span></button>'+ '</span></td></tr>';
					}
		   		 //..ENHC0127020 end
		   		 //..ENHC0127020 added else condition
		   		 else{
		   			 tableData+='<td class="table-element">' + dataAttribute.value + '</td>';
		   		 }
					
		   	 }else{
		   		tableData+='<td class="table-element"></td>';
		   	 }
		   	}
		    tableData+='</tr>';
	   }
	return tableData;
}

function doLogout(){
	window.location.href = '/logout';
}
function closeModal() { 
	$('#myModal').hide(); 
	}

//..ENHC0127020 added js for printing

function printer() {
	document.getElementById("modalExpandAllSections").click();
	 var $printModal = $("#print-modal");
	 
	  $printModal.dialog({ modal: true });
    setTimeout(function(){
    	
    	var elem = document.getElementById("mainPanelBody")
    	var domClone = elem.cloneNode(true);
        
        var $printSection = document.getElementById("printSection");
        
        if (!$printSection) {
            $printSection = document.createElement("div");
            $printSection.id = "printSection";
            document.body.appendChild($printSection);
        }
        
        $printSection.innerHTML = "";
        $printSection.appendChild(domClone);
        $printModal.dialog('close');
        window.print();
    },3000);
}

//..ENHC0127020 Ended