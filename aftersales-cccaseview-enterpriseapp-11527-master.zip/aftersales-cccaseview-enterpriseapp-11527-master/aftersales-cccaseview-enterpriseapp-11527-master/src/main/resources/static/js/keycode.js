
	var editor; // use a global for the submit and return data rendering in the examples
	 var myObj;

	$(document).ready(function() {
		console.log("new dascf test");
		/*
		
		console.log("new d test");
		
		$("#example").dataTable({
			"ajax":{
				url: "http://localhost:8080/DealerThresholdUpdate/testdata",
				type:"GET",
				  "dataType": "json"
			}
			
		});
	*/
		
	/*	editor = new $.fn.dataTable.Editor( {
	        ajax: "./testdata",
	        table: "#example",
	        idSrc: "id",
	        fields: [
	                 {
	            label: "First name:",
	            name: "name"
	            }, {
	            label: "Last name:",
	            name: "val"
	        }
	  		             
	  		        ]
	    } );*/
	/*	 $('#example').on('click', 'a.editor_edit', function (e) {
		        e.preventDefault();
		 
		        editor.edit( $(this).closest('tr'), {
		            title: 'Edit record',
		            buttons: 'Update'
		        } );
		    } );
		 
		    // Delete a record
		    $('#example').on('click', 'a.editor_remove', function (e) {
		        e.preventDefault();
		 
		        editor.remove( $(this).closest('tr'), {
		            title: 'Delete record',
		            message: 'Are you sure you wish to remove this record?',
		            buttons: 'Delete'
		        } );
		    } );*/
		 
		/* $('#example').on( 'click', 'a.editor_edit', function (e) {
		        e.preventDefault();
		 
		        editor
		            .title( 'Edit record' )
		            .buttons( { "label": "Update", "fn": function () { editor.submit() } } )
		            .edit( $(this).closest('tr') );
		    } );*/
		
		 var editIcon = function ( data, type, row ) {
		        if ( type === 'display' ) {
		            return data + ' <i class="fa fa-pencil"/>';
		        }
		        return data;
		    };
		 
		    $('#example tbody').on( 'click', 'td i', function (e) {
		        e.stopImmediatePropagation(); // stop the row selection when clicking on an icon
		 
		        editor.inline( $(this).parent() );
		    } );
		
		 $("#example").DataTable( {
		        "bProcessing": false,
		        "bServerSide": false,
		//        "dom": "Bfrtip",
		    //    "sAjaxSource": "http://localhost:8080/DealerThresholdUpdate/testdata",
		         "sAjaxSource": "./testdata",
					'paging':true,
		         "select": {
		             "style": "multi",
		             "selector": 'tr'
		         },
		         "columns": [
		         {
		        	 "aTargets":[0],"mDataProp":"select","sWidth":"1%","defaultContent":"",orderable: false,className: 'select-checkbox',"orderDataType": "dom-classes","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
					 		
						/* if(oData.indexCount=='0'){ 
	                        $(nTd).removeClass('select-checkbox'); 
						} */
						$(nTd).parents('tr').css('cursor','pointer');
					    }} ,
					    {"aTargets":[1],"mDataProp":"name","sWidth":"20%","sClass": "left","render": function (data, type, row, meta) {
			            	 	  return '<input type="text" name="name" id="name" size="40" maxlength="50" value="'+data+'" class="form-control input-xs uppercase alphanum" disabled/>';
			              }
			              },
			              {"aTargets":[2],"mDataProp":"val","sWidth":"20%","sClass": "left","render": function (data, type, row, meta) {
		            	 	  return '<input type="text" name="val" id="val" size="40" maxlength="50" value="'+data+'" class="form-control input-xs uppercase alphanum" disabled/>';
		              }
		              },
					    /*{"aTargets":[1],"mDataProp":"name","sClass": "left","defaultContent":""},
					    {"aTargets":[2],"mDataProp":"val","sClass": "left","defaultContent":""},*/
					  /*  { "data": "id" ,"searchable":false},
		                { "data": "name","searchable":true},    */
		               /* {"mRender": function ( data, type, row ) {
		                	  return '<a class="table-edit" data-id="' + row[0] + '">EDIT</a>';
	                } */
					    {"aTargets":[3],"mDataProp":"edit","defaultContent":"","sWidth":"8%","sClass": "center","sStyle":"text-align:center","sortable": false,
			            	  "render": function (data, type, row, meta) {		            		 
			            			  return  '<div class="row text-center"><a data-toggle="tooltip" data-placement="center" title="EDIT" class="fa fa-lg fa-fw fa-edit edit" href="" style="cursor: pointer;"></a>&nbsp;<a delete data-toggle="tooltip" data-placement="center" title="DELETE"   class="fa fa-lg fa-fw fa-trash-o delete"   href="" style="cursor: pointer;"></a></div>';	            		  		
			            	  }
		         }
		 ],
		/* "preDrawCallback" : function() {
       	  // Initialize the responsive datatables helper once.
       	  if (!responsiveHelper_dt_basic) {
       		  responsiveHelper_dt_basic = new ResponsiveDatatablesHelper($('#datatable'), breakpointDefinition);
       	  }
         },
         "rowCallback" : function(nRow) {
       	  responsiveHelper_dt_basic.createExpandIcon(nRow);
         },
         "drawCallback" : function(oSettings) {
       	  responsiveHelper_dt_basic.respond();
       	  //loadDropDownData(); 
         }, */
		         "oTableTools": {
	            	  "aButtons" : [			
	            	                {
	            	                	"sExtends"		: "text",
	            	                	"sButtonText"	: "<i class='fa fa-lg fa-fw fa-plus-square-o'></i>"+"Add New",
	            	                	"sButtonTitle"	: "Add New",
	            	                	"mColumns": [1,2,3,4,5,6],
	            	                	"fnClick": function( nButton, oConfig, flash ) {
	            	                		            	                	
	            	                		var table = $('#example').DataTable();
	            	                		//var index=$('#datatable').dataTable().index();
	            	                		table.row.add({'edit':'','anomalyCode':'','langCode':'','anomalyCodeDescription':'','dateAdded':$('#currentDateWithLocale').val(),'dateUpdated':$('#currentDateWithLocale').val(),'updatedBy':$("#userTID").val(),'indexCount':0}).draw( false );
	            	                	},
	            	                }
	            	                ]
		         }
				/* "aoColumns": [
				               {"aTargets":[0],"mDataProp":"select","sWidth":"10%","defaultContent":"",orderable: false,className: 'select-checkbox',"orderDataType": "dom-classes","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {

				            	   $(nTd).parents('tr').css('cursor','pointer');
				            	   return '<input type="checkbox">';
				               }} ,
		            {"aTargets":[1],"mDataProp":"name","sClass": "left","orderDataType": "dom-text","ordering": false, type: 'string',"render": function (data, type, row, meta) {      		  
		              return '<input type="text"  name="name" maxlength="4" style="width:100%" value="'+data+'" title="'+data+'" >';
		      	      }},
		      	    {"aTargets":[2],"mDataProp":"val","sClass": "left","orderDataType": "dom-text","ordering": false, type: 'string',"render": function (data, type, row, meta) {      		  
			              return '<input type="text" name="val" maxlength="4" style="width:100%" value="'+data+'" title="'+data+'" >';
			      	      }} 
		 ]*/
		         
		         /*,
			      	      
			      	    {
			                  'data': null,
			                  'className': "center",
			                  'defaultContent': '<a href="" class="editor_edit">Edit</a> / <a href="" class="editor_remove">Delete</a>'
			              }*/
		           /* { 'mData': 'name' },
		            { 'mData': 'val' }*/
		            /*,
		            {
		                'data': null,
		                'className': "center",
		                'defaultContent': '<a href="" class="editor_edit">Edit</a> / <a href="" class="editor_remove">Delete</a>'
		            }
		            {
		                'mRender': function (data, type, row) {
		                    return '<a class="table-edit" data-id="' + row[0] + '">EDIT</a>';
		                }
		            },
		             DELETE  {
		                'mRender': function (data, type, row) {
		                    return '<a class="table-delete" data-id="' + row[0] + '">DELETE</a>';
		                }
		            }*/
		        
		 //      "select": true
		       /* buttons: [
		            { extend: "create", editor: editor },
		            { extend: "edit",   editor: editor },
		            { extend: "remove", editor: editor }
		        ]*/
		    } ); 	
		 var myTable = $('#example').DataTable();
		 
		 var t = $('#example').DataTable();
		    var counter = 1;
		 
		    $('#addRow').on( 'click', function () {
		    	
		    	var table = $('#datatable').DataTable();
        		//var index=$('#datatable').dataTable().index();
        		t.row.add({'edit':'','name':'','val':'','edit':'','indexCount':0}).draw( false );

		    	
		  //      t.row.add( [counter +'.1', counter +'.2',counter +'.3'] ).draw( false );
		 
		        counter++;
		    } );
		 
		    // Automatically add a first row of data
		//    $('#addRow').click();
		// Activate an inline edit on click of a table cell
		    /*$('#example').on( 'click', 'tbody td:not(:first-child)', function (e) {
		    	debugger;
		        editor.inline( this );
		        myTable.cell( this ).edit( {
		            blur: 'submit'
		        } );
		    } );*/
		 

	        /* Apply the jEditable handlers to the table */
		 /*$('#myTable').on( 'click', 'tbody tr', function () {
			    myTable.row( this ).edit();
			    onBlur: 'submit';
			} );*/
		 $('#example').on('click','a.edit', function (e) {
				e.preventDefault();
				
				var nRow = $(this).parents('tr');
				if(nRow.find('[name="name"]').prop('disabled')){
					nRow.find('[name="name"]').prop('disabled',false);
				}
			//	clearAlertMessage();
			//	validateSpclChar();
			});
		 $('#example').on('click','a.delete', function (e) {
		//	 e.preventDefault();
			// myTable.row('.selected').remove().draw( false );
			});
	
		 $('#deleteDealerLimitBtnId').on('click',function(e){
			 e.preventDefault();
			myTable.row('.selected').remove().draw( false );
	var	checkedData  = $('#example').DataTable().rows({ active: true }).data().toArray();
	console.log("new dascf checkedData="+checkedData);
		 });
	});
		
	
	