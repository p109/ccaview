function doLogout(){
	window.location.href = '/logout';
}