package com.fca.salesforce.dao;

import java.sql.Types;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.fca.salesforce.bean.CaseViewDetailsBean;
import com.fca.salesforce.bean.InputFilterBean;
import com.fca.salesforce.constant.CaseViewConstants;
import com.fca.salesforce.mapper.CaseViewDetailsMapper;

@Repository
public class FetchCaseDetailsDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public List<CaseViewDetailsBean> getCaseViewDetailsBean(InputFilterBean inputFilterBean) {
	Object[] object1 = { inputFilterBean.getLob(), inputFilterBean.getSource() };
	int[] types = { Types.VARCHAR, Types.CHAR };
	return jdbcTemplate.query(CaseViewConstants.GET_DYNAMIC_COLUMN_NAME,
			object1, types, new CaseViewDetailsMapper()); // Sonar FIx -- Ashish
	}
}
