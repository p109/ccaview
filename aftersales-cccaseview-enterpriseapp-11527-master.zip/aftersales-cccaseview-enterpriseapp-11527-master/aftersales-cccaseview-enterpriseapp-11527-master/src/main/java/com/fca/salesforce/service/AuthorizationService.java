package com.fca.salesforce.service;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.fca.salesforce.constant.CaseViewConstants;
import com.fca.salesforce.dao.AuthorizationDao;
import com.fca.salesforce.exception.AuthorizationException;
import com.fca.salesforce.helper.CaseViewConfigResources;

/**
 * Service class required for user authorization
 *
 */
@Service
public class AuthorizationService {

	private static Logger logger = LogManager
			.getLogger(AuthorizationService.class);

	@Autowired
	CaseViewConfigResources resourceConfig;
	
	@Autowired
	AuthorizationDao authorizationDao;
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	/**
	 * Method to get Logged-in User Name Returns Username
	 * 
	 * @param accessToken
	 * @return
	 * @throws AuthorizationException 
	 * @throws UnsupportedOperationException
	 * @throws IOException
	 */
	public Map<String, String> getCurrentUserDetails(String accessToken) throws AuthorizationException  {
		final String methodName="getCurrentUserDetails";
		logger.info("inside"+methodName);
		Map<String, String> userDetailsMap = new HashMap<>();
		JSONObject jsonObject = null;
		try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
			URL url = new URL(resourceConfig.getProperty(CaseViewConstants.AZUREGRAPHURL));
			HttpGet request = new HttpGet(url.toString());
			if (CaseViewConstants.TRUE.equals(resourceConfig.getProperty(CaseViewConstants.LOCALFLAG))) {
				HttpHost proxy = new HttpHost(
						resourceConfig.getProperty(CaseViewConstants.LOCALPROXY),
						Integer.parseInt(resourceConfig
								.getProperty(CaseViewConstants.LOCALPROXYPORT)), CaseViewConstants.HTTP);
				RequestConfig config = RequestConfig.custom().setProxy(proxy)
						.build();
				request.setConfig(config);
			}

			request.setHeader("Authorization", "Bearer " + accessToken);
			logger.info(methodName,accessToken);
			request.setHeader("Accept", "application/json");
			CloseableHttpResponse httpresponse = httpclient.execute(request);
			jsonObject = (JSONObject) JSONValue.parse(new InputStreamReader(
					httpresponse.getEntity().getContent()));

		} catch (IOException ioException) {
			logger.error(methodName+"IOException " + ioException);
			throw new AuthorizationException(ioException);
		}

		if (jsonObject == null) {
			return userDetailsMap;
		}
		
		userDetailsMap.put("givenName", (String)jsonObject.get("givenName"));
		userDetailsMap.put("surname", (String)jsonObject.get("surname"));
		userDetailsMap.put("userPrincipalName", (String)jsonObject.get("userPrincipalName"));
		
		return userDetailsMap;
	}

	/**
	 * Method to get Group details of Logged-in user
	 * 
	 * @param accessToken
	 * @return
	 * @throws AuthorizationException 
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	public List<String> getMemberGroups(String accessToken) throws AuthorizationException{
		final String methodName="getMemberGroups";
		logger.info("inside "+methodName);
		ArrayList<String> groupList = new ArrayList<>();
		try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
			URL url = new URL(resourceConfig.getProperty(CaseViewConstants.AZUREGRAPHMEMBERURL));

			HttpGet request = new HttpGet(url.toString());

			if (CaseViewConstants.TRUE.equals(resourceConfig.getProperty(CaseViewConstants.LOCALFLAG))) {
				HttpHost proxy = new HttpHost(
						resourceConfig.getProperty(CaseViewConstants.LOCALPROXY),
						Integer.parseInt(resourceConfig
								.getProperty(CaseViewConstants.LOCALPROXYPORT)), CaseViewConstants.HTTP);
				RequestConfig config = RequestConfig.custom().setProxy(proxy)
						.build();
				request.setConfig(config);
			}

			request.setHeader("Authorization", "Bearer " + accessToken);
			request.setHeader("Accept", "application/json");

			CloseableHttpResponse httpresponse = httpclient.execute(request);

			JSONObject jsonObject = (JSONObject) JSONValue
					.parse(new InputStreamReader(httpresponse.getEntity()
							.getContent()));
			JSONArray jsonArray = (JSONArray) jsonObject.get("value");
			if(null != jsonArray) {
				Iterator<JSONObject> itr = jsonArray.iterator();
				while (itr.hasNext()) {
					JSONObject slide = itr.next();
					String displayName = (String) slide.get("displayName");
					groupList.add(displayName);
				}
			}

		} catch (IOException ioException) {
			logger.error(methodName,"IOException"
					+ ioException);
			throw new AuthorizationException(ioException);
		}
		logger.info(methodName, "Exit");
		return groupList;
	}
	
	public boolean insertOrUpdateUserRecord(String givenName, String surname, String emailAddress, String tid) {
		return authorizationDao.insertOrUpdateUserRecord(givenName, surname, emailAddress, tid);//changed for sonar fixes
	}


}
