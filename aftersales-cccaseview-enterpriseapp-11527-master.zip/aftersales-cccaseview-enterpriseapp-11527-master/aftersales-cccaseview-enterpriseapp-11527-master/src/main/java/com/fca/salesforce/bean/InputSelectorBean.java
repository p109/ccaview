package com.fca.salesforce.bean;

public class InputSelectorBean {

	private String slectors1;
	private String slectors2;
	private String slectors3;
	private String slectors4;
	private String slectors5;
	private String slectors6;
	private String slectors7;
	private String slectors8;
	private String slectors9;
	private String slectors10;
	public String getSlectors1() {
		return slectors1;
	}
	public void setSlectors1(String slectors1) {
		this.slectors1 = slectors1;
	}
	public String getSlectors2() {
		return slectors2;
	}
	public void setSlectors2(String slectors2) {
		this.slectors2 = slectors2;
	}
	public String getSlectors3() {
		return slectors3;
	}
	public void setSlectors3(String slectors3) {
		this.slectors3 = slectors3;
	}
	public String getSlectors4() {
		return slectors4;
	}
	public void setSlectors4(String slectors4) {
		this.slectors4 = slectors4;
	}
	public String getSlectors5() {
		return slectors5;
	}
	public void setSlectors5(String slectors5) {
		this.slectors5 = slectors5;
	}
	public String getSlectors6() {
		return slectors6;
	}
	public void setSlectors6(String slectors6) {
		this.slectors6 = slectors6;
	}
	public String getSlectors7() {
		return slectors7;
	}
	public void setSlectors7(String slectors7) {
		this.slectors7 = slectors7;
	}
	public String getSlectors8() {
		return slectors8;
	}
	public void setSlectors8(String slectors8) {
		this.slectors8 = slectors8;
	}
	public String getSlectors9() {
		return slectors9;
	}
	public void setSlectors9(String slectors9) {
		this.slectors9 = slectors9;
	}
	public String getSlectors10() {
		return slectors10;
	}
	public void setSlectors10(String slectors10) {
		this.slectors10 = slectors10;
	}
	
}
