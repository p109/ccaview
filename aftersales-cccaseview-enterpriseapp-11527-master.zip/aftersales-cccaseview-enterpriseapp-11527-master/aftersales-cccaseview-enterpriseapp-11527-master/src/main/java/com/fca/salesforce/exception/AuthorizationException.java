package com.fca.salesforce.exception;

/**
 * Exception class to handle unauthorized requests.
 *
 */
public class AuthorizationException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AuthorizationException() {
		super();
	}

	public AuthorizationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public AuthorizationException(String arg0) {
		super(arg0);
	}

	public AuthorizationException(Throwable arg0) {
		super(arg0);
	}
	
	

}
