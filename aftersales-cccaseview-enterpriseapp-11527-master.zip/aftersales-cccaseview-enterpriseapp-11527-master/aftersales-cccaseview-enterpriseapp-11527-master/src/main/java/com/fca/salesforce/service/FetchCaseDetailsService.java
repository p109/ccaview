package com.fca.salesforce.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import com.fca.salesforce.bean.CaseViewResponse;
import com.fca.salesforce.bean.InputFilterBean;
import com.fca.salesforce.exception.CaseViewException;

@Service
public interface FetchCaseDetailsService {


	CaseViewResponse getCaseDetailsOnVin(InputFilterBean inputFilterBean, HttpServletRequest request) throws  CaseViewException;

	CaseViewResponse getCaseDetailsOnCaseNumber(InputFilterBean inputFilterBean, HttpServletRequest request) throws CaseViewException;

	void getCaseDetailsAttachment(String pid,HttpServletResponse response) throws CaseViewException;
	
	//ENHC0127020 Added
	CaseViewResponse getCaseDetailsOnCaseSearch(InputFilterBean inputFilterBean, HttpServletRequest request) throws CaseViewException; 
	 
}
