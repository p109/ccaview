package com.fca.salesforce.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fca.salesforce.bean.UserBean;

public class CaseViewUserMapper implements RowMapper<UserBean> {

	@Override
	public UserBean mapRow(ResultSet rs, int arg) throws SQLException {
		
		UserBean userBean = new UserBean();
		
		userBean.setGivenName(rs.getString("N_FIRST"));
		userBean.setSurname(rs.getString("N_LAST"));
		userBean.setEmailAddress(rs.getString("X_ADDR_EMAIL"));
		userBean.setLastUpdatedDate(rs.getDate("T_STMP_LAST"));
		
		return userBean;
	}
}
