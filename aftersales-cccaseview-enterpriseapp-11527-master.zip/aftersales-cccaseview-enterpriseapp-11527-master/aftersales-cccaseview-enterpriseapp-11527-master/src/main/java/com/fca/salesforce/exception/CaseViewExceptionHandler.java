package com.fca.salesforce.exception;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.fca.salesforce.bean.CaseViewResponse;
import com.fca.salesforce.constant.CaseViewConstants;
import com.fca.salesforce.helper.CaseViewConfigResources;
import com.microsoft.aad.adal4j.AuthenticationException;

@ControllerAdvice
public class CaseViewExceptionHandler{

	@Autowired
	private CaseViewConfigResources resourceConfig;

	private static final Logger logger = LogManager
			.getLogger(CaseViewExceptionHandler.class.getName());

	/**
	 * for handling CannotGetJdbcConnectionException exception
	 * 
	 * @param request
	 * @param response
	 * @param ex
	 * @param model
	 * @return
	 */
	@ExceptionHandler(CannotGetJdbcConnectionException.class)
	public String handleCannotGetJdbcConnectionException(
			HttpServletRequest request, HttpServletResponse response,
			Exception ex, Model model) {
		logger.error(
				"handleCannotGetJdbcConnectionException Exception Method : ",
				ex);
		response.setStatus(CaseViewConstants.CANNOTGETJDBCCONNECTIONEXCEPTION);
		model.addAttribute(CaseViewConstants.WEBMSG, CaseViewConstants.DBERROR);
		model.addAttribute(CaseViewConstants.USERROLE, request.getSession()
				.getAttribute(CaseViewConstants.USERROLE));
		String copyright = resourceConfig.getProperty(CaseViewConstants.COPYRIGHT);
		model.addAttribute(CaseViewConstants.COPYRIGHT, copyright);
		model.addAttribute(CaseViewConstants.USERNAME, request.getSession()
				.getAttribute(CaseViewConstants.USERNAME));

		return CaseViewConstants.HOME;
	}

	/**
	 * for handling SQLException exception
	 * 
	 * @param request
	 * @param response
	 * @param ex
	 * @param model
	 * @return
	 */
	@ExceptionHandler(SQLException.class)
	public String handleSQLException(HttpServletRequest request, Exception ex,
			Model model) {
		logger.error("SQL Exception Method : ", ex);
		model.addAttribute(CaseViewConstants.WEBMSG, CaseViewConstants.SQLERROR);
		model.addAttribute(CaseViewConstants.USERROLE, request.getSession()
				.getAttribute(CaseViewConstants.USERROLE));
		String copyright = resourceConfig.getProperty(CaseViewConstants.COPYRIGHT);
		model.addAttribute(CaseViewConstants.COPYRIGHT, copyright);
		model.addAttribute(CaseViewConstants.USERNAME, request.getSession()
				.getAttribute(CaseViewConstants.USERNAME));
		return CaseViewConstants.HOME;
	}
	
	/**
	 * for handling DataAccessResourceFailureException exception
	 * 
	 * @param request
	 * @param response
	 * @param ex
	 * @param model
	 * @return
	 */
	@ExceptionHandler(DataAccessResourceFailureException.class)
	public String handleDataAccessResourceFailureException(
			HttpServletRequest request, HttpServletResponse response,
			Exception ex, Model model) {
		logger.error(
				"handleDataAccessResourceFailureException Exception Method : ",
				ex);
		response.setStatus(CaseViewConstants.AUTHENTICATIONEXCEPTION);
		model.addAttribute(CaseViewConstants.WEBMSG, CaseViewConstants.AUTHERROR);
		model.addAttribute(CaseViewConstants.USERROLE, request.getSession()
				.getAttribute(CaseViewConstants.USERROLE));
		String copyright = resourceConfig.getProperty(CaseViewConstants.COPYRIGHT);
		model.addAttribute(CaseViewConstants.COPYRIGHT, copyright);
		model.addAttribute(CaseViewConstants.USERNAME, request.getSession()
				.getAttribute(CaseViewConstants.USERNAME));
		return CaseViewConstants.HOME;
	}

	/**
	 * @param response
	 * @param ex
	 * @param model
	 * @return
	 */
	@ExceptionHandler(AuthenticationException.class)
	public String handleAuthenticationExceptionException(
			HttpServletRequest request, HttpServletResponse response,
			Exception ex, Model model) {
		logger.error(
				"handleAuthenticationExceptionException Exception Method : ",
				ex);
		response.setStatus(CaseViewConstants.AUTHENTICATIONEXCEPTION);
		model.addAttribute(CaseViewConstants.WEBMSG, CaseViewConstants.AUTHERROR);
		model.addAttribute(CaseViewConstants.USERROLE, request.getSession()
				.getAttribute(CaseViewConstants.USERROLE));
		String copyright = resourceConfig.getProperty(CaseViewConstants.COPYRIGHT);
		model.addAttribute(CaseViewConstants.COPYRIGHT, copyright);
		model.addAttribute(CaseViewConstants.USERNAME, request.getSession()
				.getAttribute(CaseViewConstants.USERNAME));
		return CaseViewConstants.ERROR;
	}

	/**
	 * for handling AuthorizationException exception
	 * 
	 * @param response
	 * @param ex
	 * @param model
	 * @return
	 */
	@ExceptionHandler(AuthorizationException.class)
	public String handleAuthorizationException(HttpServletRequest request,
			HttpServletResponse response, Exception ex, Model model) {
		logger.error("handleAuthorizationException Exception Method : ", ex);
		response.setStatus(CaseViewConstants.AUTHENTICATIONEXCEPTION);
		model.addAttribute(CaseViewConstants.WEBMSG, CaseViewConstants.AUTHERROR);
		model.addAttribute(CaseViewConstants.USERROLE, request.getSession()
				.getAttribute(CaseViewConstants.USERROLE));
		String copyright = resourceConfig.getProperty(CaseViewConstants.COPYRIGHT);
		model.addAttribute(CaseViewConstants.COPYRIGHT, copyright);
		model.addAttribute(CaseViewConstants.USERNAME, request.getSession()
				.getAttribute(CaseViewConstants.USERNAME));
		return CaseViewConstants.ERROR;
	}

	/**
	 * 
	 * for handling CaseViewException exception
	 * 
	 * @param request
	 * @param ex
	 * @param model
	 * @param response
	 * @return
	 * @throws IOException 
	 */
	@ExceptionHandler(CaseViewException.class)
	public ResponseEntity<CaseViewResponse> handleCaseViewException(CaseViewException ex, Model model, HttpServletResponse response)  {
		logger.error("handleCaseViewException method " , ex);
		CaseViewResponse caseViewResponce = null;
		model.addAttribute(CaseViewConstants.WEBMSG,ex.getMessage());
        try {
			response.getWriter().write(ex.getMessage());
		} catch (IOException e) {
			logger.error("handleCaseViewException Method  " , e);
		}
		return new ResponseEntity<>(caseViewResponce, HttpStatus.OK);
	}

	/**
	 * for handling Exception
	 * 
	 * @param request
	 * @param response
	 * @param ex
	 * @param model
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<CaseViewResponse> handleGenericException(HttpServletResponse response, Exception ex, Model model) {
		logger.error("Generic Exception Method : ", ex);
		if (ex instanceof IllegalStateException) {
			logger.error("Illegal State Exception");
			logger.error("Redirecting to Login Page");
		}
		CaseViewResponse caseViewResponce = null;
		model.addAttribute(CaseViewConstants.WEBMSG,"Error has occurred. Please contact System Administrator");
        try {
			response.getWriter().write(ex.getMessage());
		} catch (IOException e) {
			logger.error("handleGenericException Method   " , e);
		}
		return new ResponseEntity<>(caseViewResponce, HttpStatus.OK);
	}

	
	
}
