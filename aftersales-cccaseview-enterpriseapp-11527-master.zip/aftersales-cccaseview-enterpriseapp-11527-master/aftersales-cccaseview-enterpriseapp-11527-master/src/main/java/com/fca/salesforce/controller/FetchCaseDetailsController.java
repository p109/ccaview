package com.fca.salesforce.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.fca.salesforce.bean.CaseViewResponse;
import com.fca.salesforce.bean.InputFilterBean;
import com.fca.salesforce.exception.CaseViewException;
import com.fca.salesforce.service.FetchCaseDetailsService;

@Controller
public class FetchCaseDetailsController {
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	FetchCaseDetailsService fetchCaseDetailsService;
	
	private static Logger log = LogManager.getLogger(FetchCaseDetailsController.class);
	
	@PostMapping(value = "/getCaseDetailsOnVin",produces = {"application/json"})
	@ResponseBody
	public  ResponseEntity<CaseViewResponse> getCaseDetailsOnVin( @RequestBody InputFilterBean inputFilterBean, HttpServletRequest httpRequest) throws CaseViewException {
		final String methodName="getCaseDetailsOnVin";
		log.debug("inside "+methodName);
		CaseViewResponse caseViewResponce =fetchCaseDetailsService.getCaseDetailsOnVin(inputFilterBean, httpRequest);
		return new ResponseEntity<>(caseViewResponce, HttpStatus.OK);
	 }
	
	@PostMapping(value = "/getCaseDetailsOnCaseNumber",produces = {"application/json"})
	@ResponseBody
	public  ResponseEntity<CaseViewResponse> getCaseDetailsOnCaseNumber( @RequestBody InputFilterBean inputFilterBean, Model mvcModel, HttpServletRequest httpRequest) throws CaseViewException {
		CaseViewResponse caseViewResponce =fetchCaseDetailsService.getCaseDetailsOnCaseNumber(inputFilterBean, httpRequest);
		String recordsNotPresentInRDBMSTable = "recordsNotPresentInRDBMSTable";
		if(null != httpRequest.getAttribute(recordsNotPresentInRDBMSTable)) {
			mvcModel.addAttribute(recordsNotPresentInRDBMSTable, (String)httpRequest.getAttribute(recordsNotPresentInRDBMSTable));
		}
		return new ResponseEntity<>(caseViewResponce, HttpStatus.OK);

	 }
	
	@GetMapping(value = "/getCaseDetailsAttachment",produces = {"application/json"})
	@ResponseBody
	public  void  getCaseDetailsAttachment( @RequestParam String pid,HttpServletResponse response) throws CaseViewException {	
	fetchCaseDetailsService.getCaseDetailsAttachment(pid,response);
	}
	//ENHC0127020 adding controller
	@PostMapping(value= "/getCaseDetailsOnCaseSearch",produces = {"application/json"})
	@ResponseBody
	public ResponseEntity<CaseViewResponse> getCaseDetailsOnCaseSearch(@RequestBody InputFilterBean inputFilterBean, Model mvcModel, HttpServletRequest httpRequest) throws CaseViewException {
		CaseViewResponse caseViewResponse = fetchCaseDetailsService.getCaseDetailsOnCaseSearch(inputFilterBean, httpRequest);
		String recordsNotPresentInRDBMSTable = "recordsNotPresentInRDBMSTable";
		if(null != httpRequest.getAttribute(recordsNotPresentInRDBMSTable)) {
			mvcModel.addAttribute(recordsNotPresentInRDBMSTable, (String)httpRequest.getAttribute(recordsNotPresentInRDBMSTable));
		}
		return new ResponseEntity<>(caseViewResponse, HttpStatus.OK);
	}
   //ENHC0127020 ended
}
