package com.fca.salesforce.dao;

import java.sql.Types;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.fca.salesforce.bean.UserBean;
import com.fca.salesforce.constant.CaseViewConstants;
import com.fca.salesforce.mapper.CaseViewUserMapper;
import com.fca.salesforce.service.AuthorizationService;

@Repository
public class AuthorizationDao {
	
	private static Logger logger = LogManager
			.getLogger(AuthorizationService.class);
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	/**
	 * Method to insert Or Update User Record
	 * 
	 * @param givenName
	 * @param surname
	 * @param emailAddress
	 * @return boolean
	 */
	public boolean insertOrUpdateUserRecord(String givenName, String surname, String emailAddress, String tid) {
	final String methodName="insertOrUpdateUserRecord";
	logger.info("Inside"+methodName);
	if(null==emailAddress) {
		emailAddress= tid + "@stellantis.com";
	}
	if(null==givenName) {
		givenName="NA";
	}
	if(null==surname) {
		surname="NA";
	}
	Object[] whereClauseValuesSelect = {emailAddress.trim(),givenName.trim(),surname.trim()};
	int[] whereClauseTypesSelect = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
	
	List<UserBean> userBean = jdbcTemplate.query(
			CaseViewConstants.GET_USER_RECORD, whereClauseValuesSelect, whereClauseTypesSelect, new CaseViewUserMapper());
	
	int success ;//Changed for sonar fixes
	boolean returnValue = false;
	
	if(!userBean.isEmpty()){
		Object[] whereClauseValuesUpdate = {new Date(), emailAddress.trim(),givenName.trim(),surname.trim()};
		int[] whereClauseTypesUpdate = {Types.DATE, Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
		success = jdbcTemplate.update(CaseViewConstants.UPDATE_USER_RECORD,
				whereClauseValuesUpdate, whereClauseTypesUpdate);
	} else {
		Object[] whereClauseValuesInsert = {givenName.trim(), surname.trim(), emailAddress.trim(), new Date()};
		int[] whereClauseTypesInsert = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DATE};
		success = jdbcTemplate.update(CaseViewConstants.INSERT_USER_RECORD, whereClauseValuesInsert, whereClauseTypesInsert);
	}
	
	if(0 != success)
	{// Added as part sonar fixes
		returnValue =  true;
	}// Added as part sonar fixes
		return returnValue;
	}

}
