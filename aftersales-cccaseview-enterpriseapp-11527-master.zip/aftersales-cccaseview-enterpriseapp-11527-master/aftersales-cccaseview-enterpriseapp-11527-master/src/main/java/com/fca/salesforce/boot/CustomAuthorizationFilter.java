package com.fca.salesforce.boot;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

import javax.naming.ServiceUnavailableException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fca.salesforce.bean.AuthResults;
import com.fca.salesforce.exception.AuthorizationException;
import com.fca.salesforce.helper.AuthHelper;
import com.fca.salesforce.helper.CaseViewConfigResources;

/*
 * Added as part of AAD to ADFS Migration. STRY0480396
 * Created date 02/08/2022
*/

//@Component
public class CustomAuthorizationFilter extends OncePerRequestFilter{

	private static Logger logger = LogManager
			.getLogger(CustomAuthorizationFilter.class);

	public static final String STATES = "states";
	public static final String STATE = "state";
	public static final Integer STATE_TTL = 3600;
	public static final String FAILED_TO_VALIDATE_MESSAGE = "Failed to validate data received from Authorization service - ";
	private String clientId = "";
	private String redirect_url = "";
	private String auth_url = "";
	private final CaseViewConfigResources resourceConfig;
	
	public CustomAuthorizationFilter(CaseViewConfigResources resourceConfig2) {
			this.resourceConfig = resourceConfig2;
		//SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
	}
	
	
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		logger.info("inside CustomAuthorizationFilter:doFilterInternal() upon authentication");
	
		try {
			String currentUri = request.getRequestURL().toString();
			if(resourceConfig!=null) {
				
				clientId = resourceConfig.getProperty("ADFS_Client_Id");
				redirect_url = resourceConfig.getProperty("ADFS_Redirect_URL");
				auth_url = resourceConfig.getProperty("ADFS_Auth_URL");
				logger.info("resourceConfig is not null and local flag value"+resourceConfig.getProperty("localFlag"));
				logger.info("clientId in doFilterInternal() "+clientId);
				if (!"true".equals(resourceConfig.getProperty("localFlag"))) {
					currentUri = currentUri.replace("http", "https");
				}
			}
			

			// check if user has a AuthData in the session
			if (!AuthHelper.isAuthenticated(request)) {
				logger.info("CaseView - authenticated");
				if (AuthHelper.containsAuthenticationData(request)) {
					logger.info("CaseView - has authenticated data");
					processAuthenticationData(request);
				} else {
					logger.info("CaseView - does not have authenticated data");
					logger.info("auth_url :: {}", auth_url);
					response.sendRedirect(auth_url);
					return;
				}
			}
			
		} 

		catch (AuthorizationException exc) {
			logger.error("Error occured in doFilter:: " + exc);
			removePrincipalFromSession(request);
			response.setStatus(500);
			request.setAttribute("error", exc.getMessage());
			request.getRequestDispatcher("").forward(request, response);
		} 
		
		filterChain.doFilter(request, response);
		
	}
	
	
	private void processAuthenticationData(HttpServletRequest httpRequest) throws AuthorizationException {
		HashMap<String, String> params = new HashMap<>();
		for (String key : httpRequest.getParameterMap().keySet()) {
			params.put(key, httpRequest.getParameterMap().get(key)[0]);
		}

	
		String code = params.get("code");
		// validate that state in response equals to state in request
		try {
			if (!"".equals(code)) {
				
				// validate that OIDC Auth Response matches Code Flow (contains only requested artifacts)
//				validateAuthRespMatchesCodeFlow(oidcResponse);

				AuthResults authData = getAccessToken(code);
				logger.info("access Token: " + authData.getAccessToken());
				logger.info("access Token Type: "+ authData.getToken_type());
				logger.info("Expire in  : " + authData.getExpiresIn());
				logger.info("Id token  : " + authData.getIdToken());
				logger.info("Refresh  token  : " + authData.getRefreshToken());
				
				setSessionPrincipal(httpRequest, authData);
			} else {
				throw new AuthorizationException(String.format(
				"Request for auth code failed"));
			}
		} catch (ServiceUnavailableException | AuthorizationException e) {
			logger.error("Error occured in processAuthenticationData Method "+ e);
			throw new AuthorizationException(e.getCause());
		}
	}
	
	private AuthResults getAccessToken( String authorizationCode) throws AuthorizationException, ServiceUnavailableException
	{
		AuthResults result = null;
		
		//Post request to get access token in json response.
		String accessTokenUrl = "https://fed04.fcagroup.com/adfs/oauth2/token";
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
		logger.info("client_id env value :"+clientId);
		logger.info("redirect_url env value :"+redirect_url);
		map.add("client_id", clientId);
		map.add("code", authorizationCode);
		map.add("grant_type", "authorization_code");
		map.add("redirect_uri", redirect_url);
	
		
		HttpEntity<MultiValueMap<String, String>> postRequest = new HttpEntity<MultiValueMap<String, String>>(map, headers);
		ResponseEntity<String> postResponse = restTemplate.postForEntity( accessTokenUrl, postRequest , String.class );
		logger.info("Access Token Response ---------" + postResponse.getBody());
		
		// Get the Access Token From the recieved JSON response
		ObjectMapper mapper = new ObjectMapper();
		JsonNode node = null;
		if(!"".equals(postResponse.getBody())) {
			result = new AuthResults();
			try {
				node = mapper.readTree(postResponse.getBody());
				result.setAccessToken(node.path("access_token").asText());
				result.setExpiresIn(node.path("expires_in").asText());
				result.setIdToken(node.path("id_token").asText());
				result.setRefresh_token_expires_in(node.path("refresh_token_expires_in").asText());
				result.setRefreshToken(node.path("refresh_token").asText());
				result.setResource(node.path("resource").asText());
				result.setScope(node.path("scope").asText());
				result.setToken_type(node.path("token_type").asText());
			} catch (IOException e) {
				logger.error("Error occured getAccessToken method ::" + e);
				throw new AuthorizationException(e.getCause());
			}
		}

		if (result == null) {
			throw new ServiceUnavailableException(
					"authentication result was null");
		}
		return result;
	}
	
	
	/**
	 * @param httpRequest
	 * @param result
	 */
	private void setSessionPrincipal(HttpServletRequest httpRequest,AuthResults result) {
		httpRequest.getSession().setAttribute(AuthHelper.PRINCIPAL_SESSION_NAME, result);
	}
	
	/**
	 * @param httpRequest
	 */
	private void removePrincipalFromSession(HttpServletRequest httpRequest) {
		httpRequest.getSession().removeAttribute(
				AuthHelper.PRINCIPAL_SESSION_NAME);
	}
	
	
}
