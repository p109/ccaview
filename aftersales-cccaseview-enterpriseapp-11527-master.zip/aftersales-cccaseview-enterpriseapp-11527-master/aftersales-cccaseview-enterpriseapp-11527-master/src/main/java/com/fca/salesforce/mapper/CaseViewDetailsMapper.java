package com.fca.salesforce.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.fca.salesforce.bean.CaseViewDetailsBean;

@Component
public class CaseViewDetailsMapper implements RowMapper<CaseViewDetailsBean> {

	@Override
	public CaseViewDetailsBean mapRow(ResultSet rs, int arg) throws SQLException {
		CaseViewDetailsBean detailsBean=new CaseViewDetailsBean();
		detailsBean.setDomain(rs.getString("N_DOMN"));
		detailsBean.setSource(rs.getString("C_ATTR_SRC"));
		
		String atribute=rs.getString("X_ATTR");
		String tableName="";
		if(atribute.contains(".")) {
			tableName = atribute.substring(0,atribute.indexOf('.'));
		}
		detailsBean.setAttribute(rs.getString("X_ATTR"));
		detailsBean.setSectionNumber(rs.getInt("I_SECT_ORDR"));
		detailsBean.setAttributeNumber(rs.getInt("I_ATTR_ORDR"));
		detailsBean.setSectionName(rs.getString("N_SECT"));
		detailsBean.setDisplayAttribute(rs.getString("N_ATTR_DISP"));
		detailsBean.setLogonId(rs.getString("I_LOGON_ADD"));
		detailsBean.setTimeAdded(rs.getString("T_STMP_ADD"));
		detailsBean.setTimeUpdated(rs.getString("T_STMP_UPD"));
		detailsBean.setType(rs.getString("C_ATTR_TYP"));
		detailsBean.setTableName(tableName);
		
		return detailsBean;
	}

}
