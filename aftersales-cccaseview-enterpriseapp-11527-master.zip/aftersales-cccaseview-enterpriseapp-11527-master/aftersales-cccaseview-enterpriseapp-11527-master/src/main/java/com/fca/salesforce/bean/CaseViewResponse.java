package com.fca.salesforce.bean;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseViewResponse {

	  private String status;
	  private String timestamp;
	  private String message;
	  private List<CaseViewOutput> caseViewOutputs;
	  private Map<String,List<CaseViewDetailsBean>>  caseViewDetailsBeansMap;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<CaseViewOutput> getCaseViewOutputs() {
		return caseViewOutputs;
	}
	public void setCaseViewOutputs(List<CaseViewOutput> caseViewOutputs) {
		this.caseViewOutputs = caseViewOutputs;
	}
	public Map<String, List<CaseViewDetailsBean>> getCaseViewDetailsBeansMap() {
		return caseViewDetailsBeansMap;
	}
	public void setCaseViewDetailsBeansMap(Map<String, List<CaseViewDetailsBean>> caseViewDetailsBeansMap) {
		this.caseViewDetailsBeansMap = caseViewDetailsBeansMap;
	}
}
