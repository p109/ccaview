package com.fca.salesforce.constant;

public class CaseViewConstants {
	public static final String EMPTY = "";
	public static final String API_PROP_CONFIG_LOC_KEY = "configPropFilePath";
	public static final String API_LOG_CONFIG_LOC_KEY = "configLogFilePath";
	public static final String GET_DYNAMIC_COLUMN_NAME="Select N_DOMN,C_ATTR_SRC, X_ATTR, I_SECT_ORDR, I_ATTR_ORDR, N_SECT, N_ATTR_DISP, I_LOGON_ADD, T_STMP_ADD, T_STMP_UPD, C_ATTR_TYP ,L_ATTR_ACT FROM dbo.FCA_SCV_LOB_MAPPING WHERE N_DOMN=? AND C_ATTR_SRC=? AND L_ATTR_ACT='A' ORDER BY I_SECT_ORDR, I_ATTR_ORDR";
	public static final String GET_USER_RECORD = "SELECT * FROM DBO.FCA_SCV_USER WHERE X_ADDR_EMAIL = ? and N_FIRST=? and N_LAST=?";
	public static final String UPDATE_USER_RECORD = "UPDATE DBO.FCA_SCV_USER SET T_STMP_LAST = ? WHERE X_ADDR_EMAIL = ? and N_FIRST=? and N_LAST=?";
	public static final String INSERT_USER_RECORD = "INSERT INTO DBO.FCA_SCV_USER(N_FIRST, N_LAST, X_ADDR_EMAIL, T_STMP_LAST) VALUES (?, ?, ?, ?)";
	public static final Boolean TRUEBOOLEAN = true;
	public static final Boolean FALSEBOOLEAN = false;
	
	public static final String LEGAL_ROLE = "11527SFCV-Legal";//Changed for ADFS STRY0480396
	public static final String NON_LEGAL_ROLE = "11527SFCV-Nonlegal";//Changed for ADFS STRY0480396
	public static final String ECO_DIESEL_ROLE = "11527SFCV-EcoDiesel";//Changed for ADFS STRY0480396
	public static final String USERROLEDISPLAY = "userRoleDisplay";
	public static final String USERROLE = "userRole";
	public static final String OTHERS = "Others";
	public static final String STARTTIME = " 00:00:00";
	public static final String ENDTIME = " 23:59:59";
	public static final String FORWARDSLASH = "/";
	public static final String SIMPLEDATEFORMAT = "MM/dd/yyyy HH:mm";
	public static final String DOWNLOADRESTRICTED = "Requested CallID cannot be downloaded.";
	public static final String CALLID_LIST = "CallIDList";
	public static final String SUCCESS = "success";
	public static final String PRESENT = "present";
	public static final String LOGIN = "Login";
	public static final String REGISTRATION = "Registration";
	public static final String HOME = "Home";
	public static final String ERROR = "Error";
	public static final String SEARCH = "Search";
	public static final String ONE = "1";
	public static final String ZERO = "0";
	public static final String EMPTY_STRING = "";
	public static final String RETAINFLAG = "RetainFlag";
	public static final String UNRETAINFLAG = "unRetainFlag";
	public static final String YES = "Y";
	public static final String NO = "N";
	public static final String TID = "TID";
	public static final String WEBMSG = "webMsg";
	public static final String USERNAME = "username";
	public static final String ROLE = "ROLE";
	public static final String JNDI_NAME = "jndiName";
	public static final String CMRECORDINGINFO = "CMrecordinginfo";
	public static final String SESSION_TID = "SESSION TID";
	public static final String TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss";	
	public static final String SF_TIMESTAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String CM_ITEM = "CM.ITEM_TYPE_FOR_RECORD_SEARCH";
	public static final String DESTINATION_ABSOLUTE_PATH = "DESTINATION_ABSOLUTE_PATH";
	public static final String MARKED = "Retained";
	public static final String NOTMARKED = "Purge";
	public static final String INSUFFICIENTROLE = "User is not authorized for this action.";
	public static final String SUPERADMIN = "Super Admin";
	public static final String RETAIN = "Retain";
	public static final String UNRETAIN = "UnRetain";
	public static final String BLOBSTORAGEURL = "BLOBSTORAGEURL";
	public static final String DECRYPTED_BLOBSAS = "DECRYPTED_BLOBSAS";
	public static final String ENCRYPTED_BLOBSAS = "ENCRYPTED_BLOBSAS";
	public static final String POSITION = "POSITION";
	public static final String DOWNLOADPATH = "DOWNLOADPATH";
	public static final String RETENTION_PERIOD = "RETENTION_PERIOD";
	public static final String TRUE = "true";
	public static final String FALSE = "false";
	
	public static final String TIMEZONE_DATA="TIMEZONE_DATA";

	// User Messages
	public static final String RETENTION = "Record marked for Retention successfully.";
	public static final String ALREADYRETENTION = "Record already marked for Retention.";
	public static final String UNRETENTION = "Record marked for discard.";
	public static final String ALREADYUNRETENTION = "Record already marked for discard.";
	public static final String DOWNLOADED = "Record downloaded successfully.";
	public static final String SQLERROR = " Exception occurred while processing SQL. Please contact system administrator. ";
	public static final String AUTHERROR = " Exception occurred while User Authentication. Please contact system administrator. ";
	public static final String GENERALERROR = " Exception occurred while processing. Please contact system administrator. ";
	public static final String DBERROR = " Exception occurred Connecting to database. Please contact system administrator. ";
	public static final String USERNOTAUTHORISED = "Authorization failed. Please contact system administrator. ";
	public static final String INVALIDTID = "TID is invalid. Please enter correct ID.";
	public static final String LOGOUT = "You have been logged out";
	public static final String ILLEGALACCESS = "Please login to proceed";
	public static final String UNPROTECTEDACCESS = "Please login to proceed.";
	public static final String ERRORLISTTEXT = "Below file(s) failed decryption. Please contact System Administrator.";
	public static final String COPYRIGHT = "COPYRIGHT";
	public static final String FLAG_STATUS = "NONE";
	public static final String MIME_TYPE = "MIME_TYPE";
	public static final String I_EMAIL = "I_EMAIL";
	public static final String GROUP_LIST = "groupList";


	public static final String BR = "<br>";
	// Status Code
	public static final int CANNOTGETJDBCCONNECTIONEXCEPTION = 601;
	public static final int SQLEXCEPTION = 602;
	public static final int NOTFOUNDEXCEPTION = 603;
	public static final int GENERICEXCEPTION = 604;
	public static final int FORBIDDEN = 605;
	public static final int AUTHENTICATIONEXCEPTION = 606;
	public static final int NOCONTENTEXCEPTION = 204;
	public static final int SC_UNPROCESSABLE_ENTITY = 422;
	public static final int DOWNLOADERROR = 607;


	public static final String INPUT_FILTER_RE = "[^',\"\';]*";
	
	
    public static final String ERRORDESCRIPTION = "error_description";
    public static final String ERROR_URI = "error_uri";
    public static final String ID_TOKEN = "id_token";
    public static final String CODE = "code";
    public static final String INDEX = "index";
    public static final String ACTIVE_GROUPS = "ACTIVE_GROUPS";
    public static final String EMAIL = "email";
	public static final String CONTENTTYPE = "application/json";
	public static final String EQUALTO = "=";
	public static final String AMPERSAND = "&";
	
	//Added by Ashish
	public static final String CASE_OBJ ="CASE_OBJ";
	public static final String OBJECTSTR = "OBJECT";
	public static final String ACCEPT = "Accept";
	
	//Added by  varsha
	
	public static final String LOCALFLAG = "localFlag";
	public static final String HTTP="http";
	public static final String HTTPS = "https";
	public static final String QUESTION_MARK ="?";
	public static final String LOCALPROXY="localProxy";
	public static final String LOCALPROXYPORT="localProxyPort";
	public static final String NOT_AUTHORIZED="Not Authorized";
	public static final String LOG4J2="Log4j2.xml";
	public static final String AZUREGRAPHURL="AZURE.GRAPH.URL";
	public static final String AZUREGRAPHMEMBERURL="AZURE.GRAPH.MEMBER.URL";
	public static final String ARCHIVALAPIURL="ARCHIVAL.API.URL";
	public static final String POST="POST";
	public static final String X_IBM_CLIENT_ID="x-ibm-client-id";
	public static final String X_IBM_CLIENT_SECRET="x-ibm-client-secret";
	public static final String ARCHIVAL_API_CLIENT_ID="ARCHIVAL.API.CLIENT.ID";
	public static final String ARCHIVAL_API_CLIENT_SECRET="ARCHIVAL.API.SECRET";
	public static final String ATTACHMENT_API_URL="ATTACHMENT.API.URL";
	public static final String ATTACHMENT_API_CLIENT_ID="ATTACHMENT.API.CLIENT.ID";
	public static final String ATTACHMENT_API_SECRET="ATTACHMENT.API.SECRET";
	public static final String SFDC_API_CLIENT_ID="SFDC.API.CLIENT.ID";
	public static final String SFDC_API_SECRET="SFDC.API.SECRET";
	public static final String CCVINC ="CC_VIN__c";
	public static final String CCCASENUMBERFORMULAC="CC_Case_Number_Formula__c";
	public static final String CONTENTTYPECONST="Content-Type";
	//changed  for sonar fixes
	private CaseViewConstants() {
		
	}	
}
