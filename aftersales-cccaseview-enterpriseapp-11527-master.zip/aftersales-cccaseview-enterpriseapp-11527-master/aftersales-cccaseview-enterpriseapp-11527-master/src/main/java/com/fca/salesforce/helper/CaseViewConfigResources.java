package com.fca.salesforce.helper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.io.support.ResourcePropertySource;

import com.fca.salesforce.constant.CaseViewConstants;

@Configuration
public class CaseViewConfigResources {

	
	@Autowired
	private ApplicationContext appContext;
	
	private boolean intialized;
	private static Logger log = LogManager.getLogger(CaseViewConfigResources.class);

	/**
	 * Intialize Configuration File
	 */
	@PostConstruct
	public void initializeConfig() {

		if (intialized) {
			return;
		}
		// Initialize Logger
		initializeLogger();

		// Add Properties Files into existing property sources
		addResources();
		intialized = true;
	}
	/**
	 * to initialize and configure log properties as mentioned in xml file
	 */
	public void initializeLogger() {
		final String methodName="initializeLogger";
		log.info("inside "+methodName);
		final ConfigurableEnvironment env = (ConfigurableEnvironment) appContext
				.getEnvironment();
		if((CaseViewConstants.FALSE).equalsIgnoreCase(env.getProperty("testFlag"))) {
			final String logConfigFileLocation = env.getProperty(CaseViewConstants.API_LOG_CONFIG_LOC_KEY).concat(CaseViewConstants.LOG4J2);
			log.info(methodName,"logConfigFileLocation :: ", logConfigFileLocation);
			File f = new File(logConfigFileLocation);
			LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
			ctx.setConfigLocation(f.toURI());
			ctx.reconfigure();
			ctx.updateLoggers();
			log.info("exit initializeLogger");
		}
	}
	
	

	/**
	 * to read all property files with path mentioned in application.properties
	 */
	private void addResources() {
		final String methodName="addResources";
		log.info("inside "+methodName);
		
		
		final ConfigurableEnvironment env = (ConfigurableEnvironment) appContext
				.getEnvironment();
		log.info(methodName,"inside add ConfigurableEnvironment : {}", env);
		
		final MutablePropertySources mps = env.getPropertySources();
		final String baseLocation = env
				.getProperty(CaseViewConstants.API_PROP_CONFIG_LOC_KEY);
		log.info(methodName,"inside add baseLocation : {}", baseLocation);
		final File base = new File(baseLocation);
		log.info(methodName,"baseLocation base ", base.exists());
		try {
			if (base.exists() && base.isDirectory()) {
				File f = new File(baseLocation + "CaseView.properties");
				if (f.isFile() && f.exists()) {
					log.info(methodName,"f.isFile() : {}", f.isFile());
					log.info(methodName,"f.getName() : {}", f.getName());
					log.info(methodName,"f.getPath() : {}", f.getPath());
					mps.addLast(new ResourcePropertySource(f.getName(), "file:"
							.concat(f.getPath())));
					log.info(methodName,String.format("Property file [%s] is loaded.",
							f.getPath()));
				}

			} else {
				log.error(methodName,String
						.format("Invalid property file location [%s]. Could not load properties.",
								env.getProperty(CaseViewConstants.API_PROP_CONFIG_LOC_KEY)));
			}
		} catch (IOException e) {
			log.error(methodName,"IOException : {}", e);
		}
		log.info(methodName,"exit addResources");
	}

	/**
	 * to reload the properties
	 */
	public void refreshConfig() {
		addResources();
	}

	/**
	 * @return the value of Key given in properties loaded
	 */
	public String getProperty(String string) {
		final String value = appContext.getEnvironment().getProperty(string);
		if (null == value) {
			initializeConfig();
			return appContext.getEnvironment().getProperty(string);
		} else {
			return value;
		}
	}

	/**
	 * @return list of values for a given value in properties loaded
	 */
	public List<String> getPropertyList(String key) {
		String value = appContext.getEnvironment().getProperty(key);
		if (null == value) {
			initializeConfig();
		}
		value = appContext.getEnvironment().getProperty(key);
		if (null != value && value.length() > 0) {
			return Arrays.asList(value.split(","));
		} else {
			return new ArrayList<>();
		}
	}

}
