package com.fca.salesforce.bean;

import java.util.List;


public class InputWrapperBean {

	private InputFilterBean filters;
	private List<String> selectors;
	public InputFilterBean getFilters() {
		return filters;
	}
	public void setFilters(InputFilterBean filters) {
		this.filters = filters;
	}
	public List<String> getSelectors() {
		return selectors;
	}
	public void setSelectors(List<String> selectors) {
		this.selectors = selectors;
	}
}
