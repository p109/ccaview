package com.fca.salesforce.service;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.Cookie;
import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fca.salesforce.bean.CaseViewDetailsBean;
import com.fca.salesforce.bean.CaseViewOutput;
import com.fca.salesforce.bean.CaseViewResponse;
import com.fca.salesforce.bean.EscalationBean;
import com.fca.salesforce.bean.InputFilterBean;
import com.fca.salesforce.bean.InputWrapperBean;
import com.fca.salesforce.constant.CaseViewConstants;
import com.fca.salesforce.dao.FetchCaseDetailsDao;
import com.fca.salesforce.exception.CaseViewException;
import com.fca.salesforce.helper.CaseViewConfigResources;


@Service
public class FetchCaseDetailsServiceImpl implements FetchCaseDetailsService {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	private CaseViewConfigResources caseViewConfigResources;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	ObjectMapper mapper;
	
	@Autowired
	FetchCaseDetailsDao fetchCaseDetailsDao;

	private static final String CONTENT_DISPOSITON = "Content-Disposition";
	private static final String ATTACHMENT_FILENAME = "attachment; filename=";
	private static final String FILE_DOWNLOAD = "fileDownload";
	
	

	/**
	 * API Platform Credentials. These should be Moved to config properties file
	 */
	private static String apiToken = "";

	private static Logger log = LogManager.getLogger(FetchCaseDetailsServiceImpl.class);

	@Override
	public CaseViewResponse getCaseDetailsOnVin(InputFilterBean inputFilterBean, HttpServletRequest request)
			throws CaseViewException {
		final String methodName = "getCaseDetailsOnVin";
		log.info("Entered FetchCaseDetailsServiceImpl class" + methodName);
		CaseViewResponse caseViewResponse = new CaseViewResponse();
		
		try {
		List<CaseViewOutput> casesSalesforce = getCasesOnVINFromSalesforce(inputFilterBean);
		List<CaseViewOutput> casesArchival = getCasesOnVINFromArchival(inputFilterBean);
		List<CaseViewOutput> casesBoth = new ArrayList<>();

		for (CaseViewOutput salesforceCase : casesSalesforce) {
			casesBoth.add(salesforceCase);
		}

		List<String> groupList = getCaseDetailsOnVinChildOne(request, casesSalesforce, casesArchival, casesBoth);

		getCaseDetailsOnVinChildTwo(caseViewResponse, casesBoth, groupList);
		
		} catch (IOException | JSONException e) { // Sonar FIx -- Ashish
			log.error("Exception occurred in method getCaseDetailsOnVin :: " , e); // Sonar FIx -- Ashish
			throw new CaseViewException("Error occured while fetching cases on a VIN. Please contact System Administarator");
		} 
		return caseViewResponse;
	}

	private void getCaseDetailsOnVinChildTwo(CaseViewResponse caseViewResponse, List<CaseViewOutput> casesBoth,
			List<String> groupList) {
		List<CaseViewOutput> casesEcodiesel;
		if (groupList.contains(CaseViewConstants.ECO_DIESEL_ROLE)) {
			casesEcodiesel = new ArrayList<>();
			for (CaseViewOutput currentCase : casesBoth) {
				if ("EcoDiesel".equalsIgnoreCase(currentCase.getType())) {
					casesEcodiesel.add(currentCase);
				}
			}
			caseViewResponse.setCaseViewOutputs(casesEcodiesel);
		} else {
			caseViewResponse.setCaseViewOutputs(casesBoth);
		}
	}

	private List<String> getCaseDetailsOnVinChildOne(HttpServletRequest request, List<CaseViewOutput> casesSalesforce,
			List<CaseViewOutput> casesArchival, List<CaseViewOutput> casesBoth) {
		boolean caseAlreadyExists;
		for (CaseViewOutput archivalCase : casesArchival) {
			caseAlreadyExists = false;
			for (CaseViewOutput salesforceCase : casesSalesforce) {
				if (archivalCase.getCaseNumber().trim().equalsIgnoreCase(salesforceCase.getCaseNumber().trim())
						&& archivalCase.getLob().trim().equalsIgnoreCase(salesforceCase.getLob().trim())) {
					caseAlreadyExists = true;
					break;
				}
			}

			if (!caseAlreadyExists) {
				casesBoth.add(archivalCase);
			}
		}
		HttpSession session = request.getSession(false);
		return (ArrayList<String>) session.getAttribute("groupList");
	}

	private List<CaseViewOutput> getCasesOnVINFromSalesforce(InputFilterBean inputFilterBean) throws IOException, JSONException {
		log.info("Entered FetchCaseDetailsServiceImpl class getCasesOnVINFromSalesforce method");
		InputWrapperBean wrapperBean = new InputWrapperBean();
		CaseViewResponse caseViewResponse;
		if (inputFilterBean.getValue().length() == 8) {
			inputFilterBean.setName("Asset.CC_Last8VIN__c");
			inputFilterBean.setSfObject("Asset");
		} else if (inputFilterBean.getValue().length() == 17) {
			inputFilterBean.setName(CaseViewConstants.CCVINC);//changed for sonar fixes
			inputFilterBean.setSfObject("CASE");
		}

		wrapperBean.setFilters(inputFilterBean);
		
		
		String[] listOfSelector = {"CaseNumber",CaseViewConstants.CCCASENUMBERFORMULAC,"CC_LOB__c","CreatedDate","Contact.Name","Subject","CC_VIN__c","Status","LastModifiedDate","Type","Owner.Name"};//changed for sonar fixes

		List<String> selectors = Arrays.asList(listOfSelector);//changed for sonar fixes
		wrapperBean.setSelectors(selectors);

		JSONObject jsonrequest = createJSONRequest(wrapperBean, "S");

		JSONObject jsonResponse = callSFDCWebservice(jsonrequest, false);
		List<CaseViewOutput> caseViewOutputSF = new ArrayList<>();
		if (jsonResponse != null) {
			
			log.info("JSON response for cases from Salesforce API: " + jsonResponse.toString());
			getSalesforceWebServiceJsonResponse(jsonResponse, caseViewOutputSF);
			caseViewResponse = mapper.readValue(jsonResponse.toString(), CaseViewResponse.class);
			caseViewResponse.setCaseViewOutputs(caseViewOutputSF);
		}
		log.info("Entered FetchCaseDetailsServiceImpl class getCasesOnVINFromSalesforce method");
		return caseViewOutputSF;
	}
	
	
	
	
	public List<CaseViewOutput> getCasesOnVINFromArchival(InputFilterBean inputFilterBean)
			throws IOException, JSONException {

		InputWrapperBean wrapperBean = new InputWrapperBean();
		CaseViewResponse caseViewResponse;
		if (inputFilterBean.getValue().length() == 8) {
			inputFilterBean.setName("ASSET.CC_LAST8VIN__C");
		} else if (inputFilterBean.getValue().length() == 17) {
			inputFilterBean.setName("ASSET.CC_VIN__c");
		}
		inputFilterBean.setOperator("=");
		inputFilterBean.setNumeric(false);
		inputFilterBean.setValue(inputFilterBean.getValue());
		wrapperBean.setFilters(inputFilterBean);
		
		String[] listOfSelector = { "CASE.CASENUMBER", "CASE.CC_LOB__c", "CASE.CreatedDate", "CONTACT.FIRSTNAME",
				"CONTACT.LASTNAME", "CASE.Subject", "CASE.LastModifiedDate", "CASE.Status", "CASE.Type",
				"ASSET.CC_VIN__c", "CASE.CC_ECCICASENUMBER__C" };
		List<String> selectors;
		selectors = Arrays.asList(listOfSelector);
		wrapperBean.setSelectors(selectors);
		JSONObject jsonrequest = createJSONRequest(wrapperBean, "A");
		
		log.info("JSON request for cases from Archival API: " + jsonrequest.toString());
		
		JSONObject jsonResponse = callArchivalWebservice(jsonrequest ,"CASE");
		List<CaseViewOutput> caseViewOutputArchival = new ArrayList<>();
		if (jsonResponse != null) {
			log.info("JSON response for cases from Archival API: " + jsonResponse.toString());
			getArchivalWebServiceJsonResponse(jsonResponse, caseViewOutputArchival);
			caseViewResponse = mapper.readValue(jsonResponse.toString(), CaseViewResponse.class);
			caseViewResponse.setCaseViewOutputs(caseViewOutputArchival);
		}
		return caseViewOutputArchival;
	}

	private JSONObject callSFDCWebservice(JSONObject jsonrequest, boolean repeatCall)
			throws JSONException, IOException {
		log.info("Entered FetchCaseDetailsServiceImpl class callSFDCWebservice method");
		HttpURLConnection localHttpURLConnection = null;

		JSONObject caseNumberResponse = null;

		URL localURL;
		try {
			getToken(repeatCall);
			localURL = new URL(caseViewConfigResources.getProperty("SFDC.API.URL"));
			log.info("case validation URL: {} ", localURL);
			localHttpURLConnection = (HttpURLConnection) localURL.openConnection();
			localHttpURLConnection.setDoInput(true);
			localHttpURLConnection.setDoOutput(true);
			localHttpURLConnection.setRequestMethod("POST");
			localHttpURLConnection.setRequestProperty(CaseViewConstants.X_IBM_CLIENT_ID,
					caseViewConfigResources.getProperty("API_CLIENT_ID"));
			localHttpURLConnection.setRequestProperty(CaseViewConstants.X_IBM_CLIENT_SECRET,
					caseViewConfigResources.getProperty("API_CLIENT_SECRET"));
			localHttpURLConnection.setRequestProperty("Authorization", "Bearer " + apiToken);
			localHttpURLConnection.setRequestProperty(CaseViewConstants.CONTENTTYPECONST, CaseViewConstants.CONTENTTYPE);//changed for sonar fixes
			localHttpURLConnection.setRequestProperty(CaseViewConstants.ACCEPT, CaseViewConstants.CONTENTTYPE);//changed for sonar fixes
			log.info(" case validation request json : {} ", jsonrequest);
			OutputStream localOutputStream = localHttpURLConnection.getOutputStream();

			localOutputStream.write(jsonrequest.toString().getBytes());

			localOutputStream.flush();

			localOutputStream.close();

			int responseCode = localHttpURLConnection.getResponseCode();

			localHttpURLConnection.getResponseMessage();

			if (responseCode != 200) {
				log.error(" Error Occured - API Response code is : {}", responseCode);
				if (401 == responseCode && !repeatCall) {
					log.info(" token has expired so generating again");
					callSFDCWebservice(jsonrequest, true);
				} else {

					throw new IOException(Integer.toString(responseCode));
				}
			} else {
				caseNumberResponse = callSFDCWebserviceChildOne(localHttpURLConnection);
			}

		} catch (IOException e) {

			log.error("Case WebService exceptions() >> IOException : { }", e);
			//Sending message in order to check what has caused the exception
			throw new IOException(e.getMessage());
		}
		return caseNumberResponse;
	}
	

	private JSONObject callSFDCWebserviceChildOne(HttpURLConnection localHttpURLConnection) throws IOException, JSONException {
		JSONObject caseNumberResponseLocal = null;
		String responseString;
		BufferedReader localBufferedReader;
		//ENHC0127020 - added char set for french char fix
		localBufferedReader = new BufferedReader(
				new InputStreamReader(localHttpURLConnection.getInputStream(), StandardCharsets.UTF_8));
		responseString = localBufferedReader.readLine();
		if (null != responseString) {
			log.info(responseString);
			caseNumberResponseLocal = new JSONObject(responseString);
			log.info(" case validation response json : {} " + caseNumberResponseLocal);
			log.info(caseNumberResponseLocal.toString());
			if ("FAILURE".equalsIgnoreCase(caseNumberResponseLocal.optString("status"))) {
				log.error("Salesforce Case WebService returned message as FAILURE");
				caseNumberResponseLocal = null;
			}
		} else {
			log.info("caseResponse is null");
		}
		return caseNumberResponseLocal;
	}
//ENHC0127020 added table selector to the service function
	private JSONObject callArchivalWebservice(JSONObject jsonrequest, String table) throws JSONException {
		log.info("Entered FetchCaseDetailsServiceImpl class getCaseDetailsOnVin1 method");
		HttpURLConnection localHttpURLConnection = null;
		String responseString = null;
		JSONObject caseNumberResponse = null;
		URL localURL;
		try {
			localURL = new URL(caseViewConfigResources.getProperty("ARCHIVAL.API.URL")+table);
			log.info("case validation URL: {} ", localURL);
			localHttpURLConnection = (HttpURLConnection) localURL.openConnection();
			localHttpURLConnection.setDoOutput(true);
			localHttpURLConnection.setRequestMethod("POST");
			localHttpURLConnection.setRequestProperty("x-ibm-client-id",
					caseViewConfigResources.getProperty("ARCHIVAL.API.CLIENT.ID"));
			localHttpURLConnection.setRequestProperty("x-ibm-client-secret",
					caseViewConfigResources.getProperty("ARCHIVAL.API.SECRET"));

			localHttpURLConnection.setRequestProperty(CaseViewConstants.CONTENTTYPECONST, CaseViewConstants.CONTENTTYPE);//Changed for sonar fixes
			localHttpURLConnection.setRequestProperty(CaseViewConstants.ACCEPT, CaseViewConstants.CONTENTTYPE);//Changed for sonar fixes
			log.info(" case validation request json : {} ", jsonrequest);
			OutputStream localOutputStream = localHttpURLConnection.getOutputStream();
			localOutputStream.write(jsonrequest.toString().getBytes());
			localOutputStream.flush();
			localOutputStream.close();
			int responseCode = localHttpURLConnection.getResponseCode();

			BufferedReader localBufferedReader;
			//ENHC0127020 added character set to input
			localBufferedReader = new BufferedReader(new InputStreamReader(localHttpURLConnection.getInputStream(), StandardCharsets.UTF_8));
			responseString = localBufferedReader.readLine();
			switch (responseCode) {
			case 406:
				throw new IOException("Input(Selectors) is not defined properly");
				// should be sent to front as 500 server error
			case 200:
				caseNumberResponse = new JSONObject(responseString);
				break;
			default:
				throw new IOException("Unkown Exception");
				// should be sent to front as 500 server error
			}
		} catch (IOException e) {
			if (e.getMessage().contains("422")) {
				// archival has no data
				log.error("exceptions in callArchivalWebservice() >> IOException : { }", e);
			} else {
				// should be sent to front as 500 server error
			}
		}
		return caseNumberResponse;
	}

	private void getToken(boolean repeatCall) throws IOException, JSONException {
		log.info(" getToken() : {}", apiToken);

		String thisMethodName = "getToken";

		if (null != apiToken && !"".equalsIgnoreCase(apiToken) && !repeatCall) {
			log.debug(thisMethodName + "token is returned as repeat call is " + repeatCall);
			return;
		}

		if (repeatCall && null != apiToken) {
			apiToken = "";
		}

		try {
			URL url = new URL(caseViewConfigResources.getProperty("SFDC.TOKEN.URL"));
			HttpURLConnection conn;
			conn = (HttpURLConnection) url.openConnection();

			conn.setDoOutput(true);
			conn.setRequestProperty(CaseViewConstants.CONTENTTYPECONST, "application/x-www-form-urlencoded");//changed for sonar fixes
			conn.setRequestMethod("POST");
			conn.setRequestProperty(CaseViewConstants.X_IBM_CLIENT_ID, caseViewConfigResources.getProperty("API_CLIENT_ID"));
			conn.setRequestProperty(CaseViewConstants.X_IBM_CLIENT_SECRET, caseViewConfigResources.getProperty("API_CLIENT_SECRET"));
			conn.setRequestProperty(CaseViewConstants.ACCEPT, CaseViewConstants.CONTENTTYPE);//changed for sonar fixes

			StringBuilder inputData = new StringBuilder();

			inputData.append("grant_type").append(CaseViewConstants.EQUALTO).append("password")
					.append(CaseViewConstants.AMPERSAND).append("client_id").append(CaseViewConstants.EQUALTO)
					.append(caseViewConfigResources.getProperty("SFDC.API.CLIENT.ID"))
					.append(CaseViewConstants.AMPERSAND).append("client_secret").append(CaseViewConstants.EQUALTO)
					.append(caseViewConfigResources.getProperty("SFDC.API.SECRET"))
					.append(CaseViewConstants.AMPERSAND).append("username").append(CaseViewConstants.EQUALTO)
					.append(caseViewConfigResources.getProperty("USER_NAME")).append(CaseViewConstants.AMPERSAND)
					.append("password").append(CaseViewConstants.EQUALTO).append(caseViewConfigResources.getProperty("PASS_WORD"));

			log.info("Input Details for Token Generation : {} ", inputData);

			OutputStream os = conn.getOutputStream();

			os.write(inputData.toString().getBytes());

			os.flush();
			os.close();

			int responseCode = conn.getResponseCode();
			getTokenChildOne(conn, responseCode);
		} catch (IOException e) {
			log.error("getToken() >> IOException :{} ", e);
			throw new IOException();
		}
	}

	private void getTokenChildOne(HttpURLConnection conn, int responseCode) throws IOException, JSONException {
		if (200 != responseCode) {
			log.error("Failed : HTTP error code : " + conn.getResponseCode() + " HTTP error message : "
					+ conn.getResponseMessage());

			BufferedReader br1 = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
			if (log.isErrorEnabled()) {
				log.error(br1.readLine());
			}
			throw new IOException();

		} else {

			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			log.info(" before br.readLine()");

			String tokenString;
			tokenString = br.readLine();
			if (null != tokenString) {
				log.info("Token URL response detials : {} ", tokenString);

				JSONObject jsonObject = new JSONObject(tokenString);
				String tokenValue = (String) jsonObject.get("access_token");
				apiToken = tokenValue;

				log.info("access_token generated : {}", apiToken);

			} else {
				log.error(" Error in generating access_token : {}");
				throw new IOException();
			}
		}
	}

	@Override
	public void getCaseDetailsAttachment(String pid, HttpServletResponse response) throws CaseViewException {
		final String methodName = "callAttachmentWebserviceApi";
		try {
			String url = caseViewConfigResources.getProperty(CaseViewConstants.ATTACHMENT_API_URL);
			log.info("inside" + methodName);
			String clientId = caseViewConfigResources.getProperty(CaseViewConstants.ATTACHMENT_API_CLIENT_ID);
			String secret = caseViewConfigResources.getProperty(CaseViewConstants.ATTACHMENT_API_SECRET);
			URL httpPost = new URL(url);
			HttpsURLConnection conn = (HttpsURLConnection) httpPost.openConnection();
 			conn.setDoOutput(true);
			conn.setRequestProperty(CaseViewConstants.CONTENTTYPECONST, "application/json");//changed for sonar fixes
			conn.setRequestMethod(CaseViewConstants.POST);
			conn.setRequestProperty(CaseViewConstants.X_IBM_CLIENT_ID, clientId);

			conn.setRequestProperty(CaseViewConstants.X_IBM_CLIENT_SECRET, secret);

			DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
			JSONObject json = new JSONObject();
			json.put("pid", pid);
			String request = json.toString();
			wr.write(request.getBytes());
			wr.flush();
			wr.close();
			conn.connect();
			log.debug("Response Code:"+conn.getResponseCode());
			if (200 == conn.getResponseCode()) {
				String contentType = conn.getContentType();
				String fileName = Math.abs(pid.hashCode()) + "."
						+ contentType.substring(contentType.indexOf('/') + 1, contentType.length());// changed for sonar fixes
				response.setContentType(contentType);
				int contentLength = conn.getContentLength();
				response.setContentLength(contentLength);
				response.setHeader(CONTENT_DISPOSITON, ATTACHMENT_FILENAME + fileName);
				InputStream pdfSource = conn.getInputStream();
				ByteArrayOutputStream pdfTarget = new ByteArrayOutputStream();
				int fileChunkSize = 1024 * 4;//changed for sonar fixes
				byte[] chunk = new byte[fileChunkSize];//changed for sonar fixes
				int n ;//changed for sonar fixes
				while ((n = pdfSource.read(chunk)) != -1) {
					pdfTarget.write(chunk, 0, n);
				}
				response.setHeader(CONTENT_DISPOSITON, ATTACHMENT_FILENAME
						+ fileName);
				response.setContentType(contentType);
				response.addCookie(new Cookie(FILE_DOWNLOAD, "true"));
				response.addCookie(new Cookie("path", "/"));
				response.getOutputStream().write(pdfTarget.toByteArray());
				response.getOutputStream().flush();
				response.getOutputStream().write(pdfTarget.toByteArray());
				response.getOutputStream().flush();
			} else {
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				log.info(methodName, " before br.readLine()");
				String tokenString;
				tokenString = br.readLine();
				if (null != tokenString) {
					log.info(methodName, "Token URL response detials : {} ", tokenString);

					//ObjectMapper mapper = new ObjectMapper(); //Commented for sonar fixes
					Map<String, String> map = mapper.readValue(tokenString, Map.class);
					String tokenValue = map.get("access_token");
					apiToken = tokenValue;

					log.info(methodName, "access_token generated : {}", apiToken);
				} else {
					log.error(methodName, " Error in generating access_token : {}", apiToken);
					throw new IOException();
				}
			}
		} catch (JSONException | IOException e) {
			log.error("Exception Occured in method " + methodName  , e);
			throw new CaseViewException(" Error occurred while fetching attachment for the Case Number. Please contact System Administrator");
		} 
	}

	private static void getSalesforceWebServiceJsonResponse(JSONObject jsonResponse, List<CaseViewOutput> caseViewOutputs)
			throws JSONException {
		JSONArray jsonObjectParent = jsonResponse.getJSONArray("Dynamiccaseresponse");
		log.info("jsonResponse1 : {}" + jsonObjectParent);
		for (int i = 0; i < jsonObjectParent.length(); i++) {
			JSONObject jsonObjectCase = jsonObjectParent.getJSONObject(i);//changed for sonar fixes
			CaseViewOutput	caseViewOutput = new CaseViewOutput();
			if(jsonObjectCase.has("Contact")) {
				JSONObject jsonObjectContact = jsonObjectCase.getJSONObject("Contact");
				if(null != jsonObjectContact){
					caseViewOutput.setCallerName(checkString(jsonObjectContact.optString("Name")));
				}
			}
			if(jsonObjectCase.has("Owner")) {
				JSONObject jsonObjectOwner = jsonObjectCase.getJSONObject("Owner");
				if(null != jsonObjectOwner){
					caseViewOutput.setOwner(checkString(jsonObjectOwner.optString("Name")));
				}
			}
			// Changed case number as salesforce case number
			caseViewOutput.setCaseNumber(checkString(jsonObjectCase.optString("CaseNumber")));
			caseViewOutput.setLob(checkString(jsonObjectCase.optString("CC_LOB__c")));
			caseViewOutput.setCreatDate(checkString(jsonObjectCase.optString("CreatedDate")));
			caseViewOutput.setLastModifiedDate(checkString(jsonObjectCase.optString("LastModifiedDate")));
			caseViewOutput.setType(checkString(jsonObjectCase.optString("Type")));
			caseViewOutput.setSubject(checkString(jsonObjectCase.optString("Subject")));
			caseViewOutput.setVin(checkString(jsonObjectCase.optString(CaseViewConstants.CCVINC)));//changed for sonar fixes
			caseViewOutput.setStatus(checkString(jsonObjectCase.optString("Status")));
			caseViewOutput.setSource("S");
			
			caseViewOutputs.add(caseViewOutput);
		}
	}

	private void getArchivalWebServiceJsonResponse(JSONObject jsonResponse, List<CaseViewOutput> caseViewOutputs)
			throws JSONException {
		JSONObject result = (JSONObject) jsonResponse.get("result");
		log.info("jsonResponse1 : {}" + result);
		JSONArray jsonObjectParent = result.getJSONArray(CaseViewConstants.CASE_OBJ);//changed for sonar fixes
		for (int i = 0; i < jsonObjectParent.length(); i++) {
		JSONObject	jsonObjectContract = jsonObjectParent.getJSONObject(i);// changed for sonar fixes
		CaseViewOutput caseViewOutput = new CaseViewOutput();// changed for sonar fixes
		JSONArray jsonArrayAsset = jsonObjectContract.optJSONArray("ASSET_OBJ");
		JSONObject jsonObjectAsset = jsonArrayAsset.optJSONObject(0);
		JSONArray jsonArrayContact = jsonObjectContract.optJSONArray("CONTACT_OBJ");
		if (jsonArrayContact != null) {
		JSONObject jsonObjectContact = jsonArrayContact.optJSONObject(0);
		caseViewOutput.setCallerName(checkString(jsonObjectContact.optString("FIRSTNAME")) + " "
		+ checkString(jsonObjectContact.optString("LASTNAME")));
		}
		caseViewOutput.setLob(checkString(jsonObjectContract.optString("CC_LOB")));
		//Commented previous code and added the standard case number as output
		
		/*
		if("CAC".equalsIgnoreCase(caseViewOutput.getLob().trim())) {
			caseViewOutput.setCaseNumber(checkString(jsonObjectContract.optString("CASENUMBER")));
		}else {
			caseViewOutput.setCaseNumber(checkString(jsonObjectContract.optString("CC_ECCICASENUMBER")));
		}
		*/
		
		caseViewOutput.setCaseNumber(checkString(jsonObjectContract.optString("CASENUMBER")));
		caseViewOutput.setCreatDate(checkString(jsonObjectContract.optString("CREATEDDATE")));
		caseViewOutput.setLastModifiedDate(checkString(jsonObjectContract.optString("LASTMODIFIEDDATE")));
		caseViewOutput.setType(checkString(jsonObjectContract.optString("TYPE")));
		caseViewOutput.setSubject(checkString(jsonObjectContract.optString("SUBJECT")));
		caseViewOutput.setVin(checkString(jsonObjectAsset.optString("CC_VIN")));
		caseViewOutput.setStatus(checkString(jsonObjectContract.optString("STATUS")));
		caseViewOutput.setSource("R");
		caseViewOutputs.add(caseViewOutput);
		}
	}

	private JSONObject createJSONRequest(InputWrapperBean wrapperBean, String string)
			throws JsonProcessingException, JSONException {

		JSONObject jsonrequest = new JSONObject();
		JSONObject jsonreq = new JSONObject();

		String jsonStr = mapper.writeValueAsString(wrapperBean.getFilters());
		log.debug("jsonStr:" + jsonStr);//changed for sonar fixes
		if ("S".equalsIgnoreCase(string)) {
			jsonreq.put("SFObject", wrapperBean.getFilters().getSfObject());

		} else {
			jsonreq.put("operator", wrapperBean.getFilters().getOperator());
			jsonreq.put("isNumeric", wrapperBean.getFilters().isNumeric());

		}
		jsonreq.put("name", wrapperBean.getFilters().getName());
		//ENHC0127020 added name 
		if(wrapperBean.getFilters().getName().contains("ACCOUNT")) {
			jsonreq.put("value", wrapperBean.getFilters().getValue());
		}
		else {
			jsonreq.put("value", wrapperBean.getFilters().getValue().toUpperCase());
		}
		// ended
		JSONArray filters = new JSONArray();
		JSONArray selectorsArray = new JSONArray(wrapperBean.getSelectors());
		jsonrequest.put("selectors",selectorsArray);
		filters.put(jsonreq);
		jsonrequest.put("filters", filters);
		jsonrequest.put("selectors", selectorsArray);
		log.debug("jsonrequest:" + jsonrequest);//changed for sonar fixes
		return jsonrequest;
	}

	private static String checkString(String s) {
		String localString = s;
		if (null != s && !s.isEmpty())
			return localString.trim();
		else
			return CaseViewConstants.EMPTY;
	}
	//ENHC0127020 Added
	private void segregate(String baseText, String replaceText, List<String> baseList, List<String> segregatedList1, List<String> segregatedList2) {
		int i=0;
		String temp;
		for (i=0;i<baseList.size();i++) {
			if(baseList.get(i).contains(baseText)) {
				temp = baseList.get(i);
				temp = temp.replace(baseText, replaceText);
				segregatedList2.add(temp);
			}
			else {
				segregatedList1.add(baseList.get(i));
			}
		}
	}
	private void remove(String baseText, List<String> baseList) {
		int i=0;
		List<String> tempList = new ArrayList<>();
		for(i=0;i<baseList.size();i++) {
			if(!baseList.get(i).contains(baseText)) {
				tempList.add(baseList.get(i));
			}
			
		}
		baseList.clear();
		baseList.addAll(tempList);
	}
/*
 * The function will return the details of the case on entering case number
 * This function is hardcoded for the MOD_SERVICEDEALER__C field to be saved for archival cases.
 * If the MOD_SERVICEDEALER__OBJ field is not found then it will not work, it will only work if SERVICEDEALER field is
 * passed to get servicedealer details. Simalarly any field with MOD_ As prefix or _MOD as suffix is a modified field which is modified 
 * Specifically for application to be saved in the database mapping.
 */
	//Ended
	//ENHC0127020 added
	@Override
	public CaseViewResponse getCaseDetailsOnCaseNumber(InputFilterBean inputFilterBean, HttpServletRequest request)
			throws CaseViewException {
		
		CaseViewResponse caseViewResponce = new CaseViewResponse();
		JSONObject jsonResponse=null;;
		String caseNumber=null;
		List<String> listOfDealerSelectors;
		try {
		InputWrapperBean wrapperBean = new InputWrapperBean();
		wrapperBean.setFilters(inputFilterBean);
		if ("S".equalsIgnoreCase(inputFilterBean.getSource())) {
			wrapperBean.getFilters().setSfObject("Case");
			//Commented original code and added the case 
			//wrapperBean.getFilters().setName(CaseViewConstants.CCCASENUMBERFORMULAC);//changed for sonar fixes
			wrapperBean.getFilters().setName("CaseNumber");
		}
		
		List<CaseViewDetailsBean> viewDetailsBeans=fetchCaseDetailsDao.getCaseViewDetailsBean(inputFilterBean);
		
		//rohit added start
		if(null == viewDetailsBeans || viewDetailsBeans.isEmpty()) {
			request.setAttribute("recordsNotPresentInRDBMSTable", "Additional details for " + inputFilterBean.getLob() + " domain are not present. Please contact System Administrator");
			log.error("No records present in the Azure SQL Server table for " + inputFilterBean.getLob() + " domain and for " + inputFilterBean.getSource() + " source");
			return caseViewResponce;
		}
		//rohit added end
		
		List<String> listOfSelectors = new ArrayList<>();
		//ENHC0127020 added
		
		
		listOfDealerSelectors = new ArrayList<>();
		List<String> listOfFinalSelectors = new ArrayList<>();
		
		viewDetailsBeans.forEach(caseViewDeatilsBean -> listOfSelectors.add(caseViewDeatilsBean.getAttribute()));
		
		if("R".equalsIgnoreCase(inputFilterBean.getSource().trim())) {
			
			segregate("SERVICINGDEALER", "ACCOUNT", listOfSelectors, listOfFinalSelectors, listOfDealerSelectors);
			remove("NAFTA_ESCALATION", listOfFinalSelectors);
			remove("NAFTA_ESCALATION_UPDATE", listOfFinalSelectors);
			listOfFinalSelectors.add("CASE.CC_SERVICINGDEALER__C");
			listOfFinalSelectors.add("CASE.CASENUMBER");
			wrapperBean.setSelectors(listOfFinalSelectors);
			JSONObject jsonrequest1 = createJSONRequest(wrapperBean, inputFilterBean.getSource());
			JSONObject jsonResponse1 = callArchivalWebservice(jsonrequest1,"CASE");
			if(jsonResponse1!=null) {
				JSONObject result1 = jsonResponse1.getJSONObject("result").getJSONArray("CASE_OBJ").getJSONObject(0);
				String servicingDealerId = result1.optString("CC_SERVICINGDEALER");
				caseNumber = result1.optString("CASENUMBER");
				JSONArray servicingDealerObj = getServicingDealerArray(servicingDealerId, wrapperBean.getFilters());
				if(servicingDealerObj!=null) {
					
					jsonResponse1.getJSONObject("result").getJSONArray("CASE_OBJ").getJSONObject(0).put("MOD_SERVICINGDEALER_OBJ", servicingDealerObj);
				}


				JSONObject escalationCaseObject = getEscalationObjectForArchival(caseNumber, wrapperBean.getFilters());
				if(escalationCaseObject!=null) {
				createEscalationTemplate(escalationCaseObject, "R");
				jsonResponse1.getJSONObject("result").getJSONArray("CASE_OBJ").getJSONObject(0).put("MOD_NAFTA_ESCALATION_OBJ", escalationCaseObject.optJSONArray("NAFTA_ESCALATION_OBJ"));
				//jsonResponse1.getJSONObject("result").getJSONArray("CASE_OBJ").getJSONObject(0).put("MOD_NAFTA_ESCALATION_UPDATE_OBJ", escalationCaseObject.optJSONArray("NAFTA_ESCALATION_UPDATE_OBJ"));
				}
			}
			
			jsonResponse = jsonResponse1;

		}
		else {
			//Logic to retrive dealer details for salesfocrce
			listOfFinalSelectors = listOfSelectors;
			remove("CC_ServicingDealer__r_mod", listOfFinalSelectors);
			remove("Escalations__r.EscalationDetailsDescription_mod", listOfFinalSelectors);
			remove("Escalations__r.EscalatedTo_mod", listOfFinalSelectors);
			listOfFinalSelectors.add("Escalations__r.RecordTypeId");
			addEscalationSelectors(listOfFinalSelectors, "S");
			wrapperBean.setSelectors(listOfFinalSelectors);
			
			JSONObject jsonrequest = createJSONRequest(wrapperBean, inputFilterBean.getSource());
			JSONObject jsonResponse1;

			
			jsonResponse1 = callSFDCWebservice(jsonrequest, false);
			
			
			if(jsonResponse1!=null) {
				JSONObject servicingDlr = getServicingDealerForS(jsonResponse1);
				jsonResponse1.getJSONArray("Dynamiccaseresponse").getJSONObject(0).put("CC_ServicingDealer__r_mod", servicingDlr);
				
				createEscalationTemplate(jsonResponse1, "S");
			}
			jsonResponse = jsonResponse1;
		
		}
		
		
		if(null != jsonResponse) {
			log.info("Json request for r source {}", jsonResponse);
			caseViewResponce = mapper.readValue(jsonResponse.toString(), CaseViewResponse.class);
		}
		Map<String, List<CaseViewDetailsBean>> maps = new LinkedHashMap<>();
		if ("S".equalsIgnoreCase(inputFilterBean.getSource().trim())) {
			createDynamicResponseSFDC(viewDetailsBeans, jsonResponse, maps);
		} else {
			createDynamicResponseArchival(viewDetailsBeans, jsonResponse, maps);
		}
		
		caseViewResponce.setCaseViewDetailsBeansMap(maps);
		} catch (JSONException |IOException e) { // Sonar FIx -- Ashish
			log.error("Exception occurred in method getCaseDetailsOnCaseNumber :: " , e); 
			throw new CaseViewException("Error occurred while fetching additional case details. Please contact System Administrator");
		}
		return caseViewResponce;
	}
	
//ENHC0127020 ADDED
	
	private  JSONObject getServicingDealerForS(JSONObject jsonResponse) {
		try {
			jsonResponse.getJSONArray("ServicingDealer").getJSONObject(0).getJSONObject("CC_ServicingDealer__r").put("DealerAddress_mod", createAddress(jsonResponse, "S"));
			return jsonResponse.getJSONArray("ServicingDealer").getJSONObject(0).getJSONObject("CC_ServicingDealer__r");
		}
		catch(JSONException e) {
			log.error("Exception occurred in getting Servicing dealer:: " , e);
			return null;
			
		}
	}
	
	private void createEscalationTemplate(JSONObject jsonResponse, String src) {
	JSONObject escObj = null;
	JSONArray escArray = null;
	int size = 0;
	try {
		EscalationBean escBean = null;
		if("S".equalsIgnoreCase(src)) {
			escObj = jsonResponse.getJSONArray("Dynamiccaseresponse").getJSONObject(0).getJSONObject("Escalations__r");
			if(escObj!=null) {
				size = escObj.getInt("totalSize");
				escArray = escObj.getJSONArray("records");
				for(int i=0; i<size; i++) {
					String record = escArray.getJSONObject(i).optString("RecordTypeId");
					escBean = new EscalationBean();
					setFieldsForEscalation(escArray, record, escBean,"S", i);
					escBean.setEscalatedTo();
					escObj.getJSONArray("records").getJSONObject(i).put("EscalatedTo_mod", escBean.getEscalatedTo());
					escObj.getJSONArray("records").getJSONObject(i).put("EscalationDetailsDescription_mod", escBean.toString());
				}
			}
		}else {
			escObj = jsonResponse;
			if(escObj!=null) {
				escArray = escObj.getJSONArray("NAFTA_ESCALATION_OBJ");
				if(escArray!=null) {
				size = escArray.length();
				for(int i=0;i<size;i++) {
					String record = escArray.getJSONObject(i).optString("RECORDTYPEID");
					escBean = new EscalationBean();
					setFieldsForEscalation(escArray, record, escBean,"R", i);
					escBean.setEscalatedTo();
					escArray.getJSONObject(i).put("ESCALATIONRECORDTYPE_MOD", escBean.getEscalatedTo());
					escObj.getJSONArray("NAFTA_ESCALATION_OBJ").getJSONObject(i).put("ESCALATIONDETAILSDESCRIPTION", escBean.toString());
				}
			}
			}
		}
		
	}
		catch (JSONException e) {
			log.debug("Exception occured in creating Escalation Template", e);
		}
	}
	
	
	private void setFieldsForEscalation(JSONArray escArray, String record, EscalationBean escBean,String src, int index) {
		if("S".equalsIgnoreCase(src)) {
			escBean.setEmailPartSpec(getFieldFromJsonArray(escArray, index, "CC_EmailPartSpecifying__c"));
			escBean.setEscComment(getFieldFromJsonArray(escArray, index, "NAFTA_EscalationComment__c"));
			escBean.setReasonForEsc(getFieldFromJsonArray(escArray, index, "NAFTA_ReasonForEscalation__c"));
			escBean.setCoreGroup(getFieldFromJsonArray(escArray, index, "NAFTA_CoreGroup__c"));
			escBean.setCustomerWaiting(getFieldFromJsonArray(escArray, index, "NAFTA_CustomerWaiting__c"));
			escBean.setUnableToDuplicate(getFieldFromJsonArray(escArray, index, "NAFTA_UnableToDuplicate__c"));
			escBean.setUnableToDiagonize(getFieldFromJsonArray(escArray, index, "NAFTA_UnableToDiagnosis__c"));
			escBean.setUnableToRepair(getFieldFromJsonArray(escArray, index, "NAFTA_UnableToRepair__c"));
			escBean.setRepeatRepair(getFieldFromJsonArray(escArray, index, "NAFTA_RepeatRepair__c"));
			escBean.setQueueName(getFieldFromJsonArray(escArray, index, "CC_QueueName__c"));
			escBean.setOmcNumber(getFieldFromJsonArray(escArray, index, "NAFTA_OmcNumber__c"));
			escBean.setPartNumber(getFieldFromJsonArray(escArray, index, "NAFTA_PartNumber__c"));
			escBean.setOrderNumber(getFieldFromJsonArray(escArray, index, "NAFTA_OrderNumber__c"));
			
		}
		else {
			escBean.setEmailPartSpec(getFieldFromJsonArray(escArray, index, "CC_EMAILPARTSPECIFYING"));
			escBean.setEscComment(getFieldFromJsonArray(escArray, index, "NAFTA_ESCALATIONCOMMENT"));
			escBean.setReasonForEsc(getFieldFromJsonArray(escArray, index, "NAFTA_REASONFORESCALATION"));
			escBean.setCoreGroup(getFieldFromJsonArray(escArray, index, "NAFTA_COREGROUP"));
			escBean.setCustomerWaiting(getFieldFromJsonArray(escArray, index, "NAFTA_CUSTOMERWAITING"));
			escBean.setUnableToDuplicate(getFieldFromJsonArray(escArray, index, "NAFTA_UNABLETODUPLICATE"));
			escBean.setUnableToDiagonize(getFieldFromJsonArray(escArray, index, "NAFTA_UNABLETODIAGNOSIS"));
			escBean.setUnableToRepair(getFieldFromJsonArray(escArray, index, "NAFTA_UNABLETOREPAIR"));
			escBean.setRepeatRepair(getFieldFromJsonArray(escArray, index, "NAFTA_REPEATREPAIR"));
			escBean.setQueueName(getFieldFromJsonArray(escArray, index, "CC_QUEUENAME"));
			escBean.setOmcNumber(getFieldFromJsonArray(escArray, index, "NAFTA_OMCNUMBER"));
			escBean.setPartNumber(getFieldFromJsonArray(escArray, index, "NAFTA_PARTNUMBER"));
			escBean.setOrderNumber(getFieldFromJsonArray(escArray, index, "NAFTA_ORDERNUMBER"));

		}
		escBean.setRecordId(record);
	}
	private String getFieldFromJsonArray(JSONArray arr, int index, String field) {
		 try{
			 return arr.getJSONObject(index).optString(field)!=null?arr.getJSONObject(index).optString(field):"";
			 }
		 catch(JSONException e) {
			 log.debug("Error in method getFieldsFromJsonArray ::", e);
			 return "";
		 }
	}
	private void addEscalationSelectors(List<String> selectorList, String src) {
		if(("S").equalsIgnoreCase(src)) {
			selectorList.add("Escalations__r.NAFTA_ReasonForEscalation__c");
			selectorList.add("Escalations__r.NAFTA_EscalationComment__c");
			selectorList.add("Escalations__r.CC_EmailPartSpecifying__c");
			selectorList.add("Escalations__r.NAFTA_CoreGroup__c");
			selectorList.add("Escalations__r.NAFTA_CustomerWaiting__c");
			selectorList.add("Escalations__r.NAFTA_UnableToDuplicate__c");
			selectorList.add("Escalations__r.NAFTA_UnableToDiagnosis__c");
			selectorList.add("Escalations__r.NAFTA_UnableToRepair__c");
			selectorList.add("Escalations__r.NAFTA_RepeatRepair__c");
			selectorList.add("Escalations__r.CC_QueueName__c");
			selectorList.add("Escalations__r.NAFTA_PartNumber__c");
			selectorList.add("Escalations__r.NAFTA_OmcNumber__c");
			selectorList.add("Escalations__r.NAFTA_OrderNumber__c");
		}
		else {
			selectorList.add("NAFTA_ESCALATION.NAFTA_REASONFORESCALATION");
			selectorList.add("NAFTA_ESCALATION.CC_EMAILPARTSPECIFYING");
			selectorList.add("NAFTA_ESCALATION.NAFTA_ESCALATIONCOMMENT");
			selectorList.add("NAFTA_ESCALATION.NAFTA_COREGROUP");
			selectorList.add("NAFTA_ESCALATION.NAFTA_CUSTOMERWAITING");
			selectorList.add("NAFTA_ESCALATION.NAFTA_UNABLETODUPLICATE");
			selectorList.add("NAFTA_ESCALATION.NAFTA_UNABLETODIAGNOSIS");
			selectorList.add("NAFTA_ESCALATION.NAFTA_UNABLETOREPAIR");
			selectorList.add("NAFTA_ESCALATION.NAFTA_REPEATREPAIR");
			selectorList.add("NAFTA_ESCALATION.CC_QUEUENAME");
			selectorList.add("NAFTA_ESCALATION.NAFTA_PARTNUMBER");
			selectorList.add("NAFTA_ESCALATION.NAFTA_OMCNUMBER");
			selectorList.add("NAFTA_ESCALATION.NAFTA_ORDERNUMBER");

		}
	}


	
	/*
	 * Customized function for adding escalation details in order to show details and wrapping id's to the actual case name for updates
	 */
	private JSONObject getEscalationObjectForArchival(String caseNumber, InputFilterBean filter) {
		try {
			InputWrapperBean wrapperBean = new InputWrapperBean();
			filter.setName("CASE.CASENUMBER");
			filter.setValue(caseNumber);
			List<String> listOfEscalationSelector = new ArrayList<>();
			listOfEscalationSelector.add("NAFTA_ESCALATION.*");
			listOfEscalationSelector.add("NAFTA_ESCALATION_UPDATE.*");
			listOfEscalationSelector.add("CASE.CASENUMBER");
			wrapperBean.setFilters(filter);
			wrapperBean.setSelectors(listOfEscalationSelector);
			JSONObject jsonrequest = createJSONRequest(wrapperBean, wrapperBean.getFilters().getSource());
			
			JSONObject jsonResponse = callArchivalWebservice(jsonrequest,"CASE");
			if(jsonResponse!=null) {
				return jsonResponse.getJSONObject("result").getJSONArray("CASE_OBJ").getJSONObject(0);
			}
			else {
				return null;
			}
			
		}
		catch(JSONException | IOException e) {
			log.error("Exception occured in method getEscalationObjectFromArchival ::", e);
			log.error("Not able to find dealer details");
			return null;
		}

	}
	private JSONArray getServicingDealerArray(String dealerId, InputFilterBean filter) {
		if(Objects.isNull(dealerId) || Strings.isEmpty(dealerId)) {
			return null;
		}
		else {
			try {
				InputWrapperBean wrapperBean = new InputWrapperBean();
				wrapperBean.setFilters(filter);
				wrapperBean.getFilters().setValue(dealerId);
				wrapperBean.getFilters().setName("ACCOUNT.ID");
				List<String> listOfDealerSelectors = new ArrayList<>();
				listOfDealerSelectors.add("CASE.CASENUMBER");
				listOfDealerSelectors.add("ACCOUNT.*");
				wrapperBean.setSelectors(listOfDealerSelectors);
				JSONObject jsonrequest = createJSONRequest(wrapperBean, wrapperBean.getFilters().getSource());
				
				JSONObject jsonResponse = callArchivalWebservice(jsonrequest,"ACCOUNT");
				if(jsonResponse!=null) {
					jsonResponse.getJSONObject("result").getJSONArray("ACCOUNT_OBJ").getJSONObject(0).put("DEALERADDRESS_MOD", createAddress(jsonResponse,"R"));
					return jsonResponse.getJSONObject("result").getJSONArray("ACCOUNT_OBJ");
				}
				else {
					return null;
				}
			}
			catch(JSONException | IOException e) {
				log.error("Exception occured in method getServicingDealerObject ::", e);
				log.error("Not able to find dealer details");
				return null;
			}
		}
	}
	private String createAddress(JSONObject jsonResponse, String src) {
		String street = null;
		String state = null;
		String country = null;
		String postal = null;
		String city = null;
		String address = null;
		String comma = ", ";
		String space = " ";
		
		try {
		if("R".equalsIgnoreCase(src)) {
			street = jsonResponse.getJSONObject("result").getJSONArray("ACCOUNT_OBJ").getJSONObject(0).optString("BILLINGSTREET");
			state = jsonResponse.getJSONObject("result").getJSONArray("ACCOUNT_OBJ").getJSONObject(0).optString("BILLINGSTATE");
			postal = jsonResponse.getJSONObject("result").getJSONArray("ACCOUNT_OBJ").getJSONObject(0).optString("BILLINGPOSTALCODE");
			country = jsonResponse.getJSONObject("result").getJSONArray("ACCOUNT_OBJ").getJSONObject(0).optString("BILLINGCOUNTRY");
			city = jsonResponse.getJSONObject("result").getJSONArray("ACCOUNT_OBJ").getJSONObject(0).optString("BILLINGCITY");
		}
		else {
			street = jsonResponse.getJSONArray("ServicingDealer").getJSONObject(0).getJSONObject("CC_ServicingDealer__r").optString("BillingStreet");
			state = jsonResponse.getJSONArray("ServicingDealer").getJSONObject(0).getJSONObject("CC_ServicingDealer__r").optString("BillingState");
			postal = jsonResponse.getJSONArray("ServicingDealer").getJSONObject(0).getJSONObject("CC_ServicingDealer__r").optString("BillingPostalCode");
			country = jsonResponse.getJSONArray("ServicingDealer").getJSONObject(0).getJSONObject("CC_ServicingDealer__r").optString("BillingCountry");
			city = jsonResponse.getJSONArray("ServicingDealer").getJSONObject(0).getJSONObject("CC_ServicingDealer__r").optString("BillingCity");
		}
		address = (Objects.isNull(street)?"":street+space)
				+(Objects.isNull(city)?"":(city+comma)) 
				+(Objects.isNull(state)?"":(state+space)) 
				+(Objects.isNull(postal)?"":(postal+space))
				+(Objects.isNull(country)?"":(country));
		
		
		return address;
		}catch(JSONException e) {
			log.debug("Exception occured in createAddress::", e);
			return "";
		}
	}
 //ENHC0127020 ended
	private void createDynamicResponseSFDC(List<CaseViewDetailsBean> viewDetailsBeans, JSONObject jsonResponse,
			Map<String, List<CaseViewDetailsBean>> maps) throws JSONException {
		JSONObject dynamicCaseResponseObj = jsonResponse.optJSONArray("Dynamiccaseresponse").getJSONObject(0);
		setDynamicSalesforceResponse(viewDetailsBeans, dynamicCaseResponseObj, maps);//changed for sonar fixes
	}

	private void createDynamicResponseArchival(List<CaseViewDetailsBean> viewDetailsBeans, JSONObject jsonResponse,
			Map<String, List<CaseViewDetailsBean>> maps) throws JSONException {
		JSONObject dynamicCaseResponseObj = jsonResponse.getJSONObject("result");
		setDynamicArchivalResponse(viewDetailsBeans, dynamicCaseResponseObj, maps);

	}

	private void setDynamicSalesforceResponse(List<CaseViewDetailsBean> viewDetailsBeans,
			JSONObject dynamicCaseResponseObj, Map<String, List<CaseViewDetailsBean>> maps) {//changed for sonar fixes
		
		for (CaseViewDetailsBean caseViewDetailsBean : viewDetailsBeans) {
			
			String columnName = getSalesforceCloumnName(caseViewDetailsBean.getAttribute());
			String parentJsonAttributeName = caseViewDetailsBean.getTableName();
			
			if (!"".equalsIgnoreCase(parentJsonAttributeName.trim())) {
				setDynamicSalesforceResponseChildFour(dynamicCaseResponseObj, maps, caseViewDetailsBean, columnName,
						parentJsonAttributeName);
			} else {
				setDynamicSalesforceResponseChildThree(dynamicCaseResponseObj, maps, caseViewDetailsBean, columnName);
			}
		}
	}

	private void setDynamicSalesforceResponseChildFour(JSONObject dynamicCaseResponseObj,
			Map<String, List<CaseViewDetailsBean>> maps, CaseViewDetailsBean caseViewDetailsBean, String columnName,
			String parentJsonAttributeName) {
		JSONObject parentJsonObject = dynamicCaseResponseObj.optJSONObject(parentJsonAttributeName);
		if (parentJsonObject != null) {
			if(CaseViewConstants.OBJECTSTR.equalsIgnoreCase(caseViewDetailsBean.getType().trim()) || "LIST".equalsIgnoreCase(caseViewDetailsBean.getType().trim())) {//changed for sonar fixes
				setDynamicSalesforceResponseChildOne(maps, caseViewDetailsBean, columnName, parentJsonObject);
				
			} else if("TABLE".equalsIgnoreCase(caseViewDetailsBean.getType().trim()) || ("ATTACHMENT".equalsIgnoreCase(caseViewDetailsBean.getType().trim()))) {
				setDynamicSalesforceResponseChildTwo(maps, caseViewDetailsBean, columnName, parentJsonObject);
			}
		}
	}

	private void setDynamicSalesforceResponseChildThree(JSONObject dynamicCaseResponseObj,
			Map<String, List<CaseViewDetailsBean>> maps, CaseViewDetailsBean caseViewDetailsBean, String columnName) {
		if (CaseViewConstants.OBJECTSTR.equalsIgnoreCase(caseViewDetailsBean.getType().trim())) {//changed for sonar fixes
			String leafElementValue = dynamicCaseResponseObj.optString(columnName);
			caseViewDetailsBean.setValue(formatData(leafElementValue));
		}
		
		if(maps.containsKey(caseViewDetailsBean.getSectionName().trim()))
			maps.get(caseViewDetailsBean.getSectionName().trim()).add(caseViewDetailsBean);
		else {
			List<CaseViewDetailsBean> list=new ArrayList<>();
			list.add(caseViewDetailsBean);
			maps.put(caseViewDetailsBean.getSectionName().trim(),list);
		}
	}

	private void setDynamicSalesforceResponseChildTwo(Map<String, List<CaseViewDetailsBean>> maps,
			CaseViewDetailsBean caseViewDetailsBean, String columnName, JSONObject parentJsonObject) {
		String columnName1;
		String columnName2;
		JSONObject jsonObjectAtThirdLayer;
		JSONArray jsonAttributeArray = parentJsonObject.optJSONArray("records");
		for(int i=0 ;i <jsonAttributeArray.length();i++) {
			
			JSONObject jsonAttributeObject = jsonAttributeArray.optJSONObject(i);
			CaseViewDetailsBean caseViewDeatilsColBean = new CaseViewDetailsBean();
			caseViewDeatilsColBean.setAttribute(caseViewDetailsBean.getAttribute());
			caseViewDeatilsColBean.setAttributeNumber(caseViewDetailsBean.getAttributeNumber());
			caseViewDeatilsColBean.setDisplayAttribute(caseViewDetailsBean.getDisplayAttribute());
			caseViewDeatilsColBean.setDomain(caseViewDetailsBean.getDomain());
			caseViewDeatilsColBean.setLogonId(caseViewDetailsBean.getLogonId());
			caseViewDeatilsColBean.setSectionName(caseViewDetailsBean.getSectionName());
			caseViewDeatilsColBean.setSectionNumber(caseViewDetailsBean.getSectionNumber());
			caseViewDeatilsColBean.setSource(caseViewDetailsBean.getSource());
			caseViewDeatilsColBean.setTableName(caseViewDetailsBean.getTableName());
			caseViewDeatilsColBean.setTimeAdded(caseViewDetailsBean.getTimeAdded());
			caseViewDeatilsColBean.setTimeUpdated(caseViewDetailsBean.getTimeUpdated());
			caseViewDeatilsColBean.setType(caseViewDetailsBean.getType());
			if(columnName.contains(".")) {
				columnName1 = columnName.substring(0,columnName.indexOf('.'));
				columnName2 = columnName.substring(columnName.indexOf('.') + 1);
				jsonObjectAtThirdLayer = jsonAttributeObject.optJSONObject(columnName1);
				String leafElementValue = jsonObjectAtThirdLayer.optString(columnName2);
				caseViewDeatilsColBean.setValue(formatData(leafElementValue));
			} else {
				String leafElementValue = jsonAttributeObject.optString(columnName);
				caseViewDeatilsColBean.setValue(formatData(leafElementValue));
			}
			if(maps.containsKey(caseViewDeatilsColBean.getSectionName().trim()))
				maps.get(caseViewDeatilsColBean.getSectionName().trim()).add(caseViewDeatilsColBean);
			else {
				List<CaseViewDetailsBean> list=new ArrayList<>();
				list.add(caseViewDeatilsColBean);
				maps.put(caseViewDetailsBean.getSectionName().trim(),list);
			}
		}
	}

	private void setDynamicSalesforceResponseChildOne(Map<String, List<CaseViewDetailsBean>> maps,
			CaseViewDetailsBean caseViewDetailsBean, String columnName, JSONObject parentJsonObject) {
		String columnName1;
		String columnName2;
		JSONObject jsonObjectAtThirdLayer;
		if(columnName.contains(".")) {
			columnName1 = columnName.substring(0,columnName.indexOf('.'));
			columnName2 = columnName.substring(columnName.indexOf('.') + 1);
			jsonObjectAtThirdLayer = parentJsonObject.optJSONObject(columnName1);
			String leafElementValue = jsonObjectAtThirdLayer.optString(columnName2);
			caseViewDetailsBean.setValue(formatData(leafElementValue));
		} else {
			String leafElementValue = parentJsonObject.optString(columnName);
			caseViewDetailsBean.setValue(formatData(leafElementValue));
		}
		
		if(maps.containsKey(caseViewDetailsBean.getSectionName().trim()))
			maps.get(caseViewDetailsBean.getSectionName().trim()).add(caseViewDetailsBean);
		else {
			List<CaseViewDetailsBean> list=new ArrayList<>();
			list.add(caseViewDetailsBean);
			maps.put(caseViewDetailsBean.getSectionName().trim(),list);
		}
	}

	private void setDynamicArchivalResponse(List<CaseViewDetailsBean> viewDetailsBeans, 
			JSONObject dynamicCaseResponseObj, Map<String, List<CaseViewDetailsBean>> maps) {//changed for sonar fixes

		for (CaseViewDetailsBean caseViewDetailsBean : viewDetailsBeans) {
			setDynamicArchivalResponseChildFive(dynamicCaseResponseObj, maps, caseViewDetailsBean);
		}
	}

	private void setDynamicArchivalResponseChildFive(JSONObject dynamicCaseResponseObj,
			Map<String, List<CaseViewDetailsBean>> maps, CaseViewDetailsBean caseViewDetailsBean) {
		String columnName = getCloumnName(caseViewDetailsBean.getAttribute()).toUpperCase();
		String parentJsonAttributeName = caseViewDetailsBean.getTableName() + "_OBJ";
		if (!CaseViewConstants.CASE_OBJ.equalsIgnoreCase(parentJsonAttributeName)) {//Changed for sonar fixes
			JSONObject parentJsonObject = dynamicCaseResponseObj.optJSONArray(CaseViewConstants.CASE_OBJ).optJSONObject(0);//changed for sonar fixes
			if (parentJsonObject != null) {
				setDynamicArchivalResponseChildSix(maps, caseViewDetailsBean, columnName, parentJsonAttributeName,
						parentJsonObject);
			}
		} else {
			setDynamicArchivalResponseChildFour(dynamicCaseResponseObj, maps, caseViewDetailsBean, columnName,
					parentJsonAttributeName);
		}
	}

	private void setDynamicArchivalResponseChildSix(Map<String, List<CaseViewDetailsBean>> maps,
			CaseViewDetailsBean caseViewDetailsBean, String columnName, String parentJsonAttributeName,
			JSONObject parentJsonObject) {
		JSONArray jsonAttributeArray = parentJsonObject.optJSONArray(parentJsonAttributeName);
		if (jsonAttributeArray != null) {
			if ("LIST".equalsIgnoreCase(caseViewDetailsBean.getType().trim())) {
				setDynamicArchivalResponseChildOne(maps, caseViewDetailsBean, columnName,
						jsonAttributeArray);
				
			} else if (CaseViewConstants.OBJECTSTR.equalsIgnoreCase(caseViewDetailsBean.getType().trim())) {//changed for sonar fixes
				setDynamicArchivalResponseChildTwo(maps, caseViewDetailsBean, columnName, parentJsonObject);
				
			} else if ("TABLE".equalsIgnoreCase(caseViewDetailsBean.getType().trim())
					|| ("ATTACHMENT".equalsIgnoreCase(caseViewDetailsBean.getType().trim()))) {
				setDynamicArchivalResponseChildThree(maps, caseViewDetailsBean, columnName,
						jsonAttributeArray);
			}
		}
	}

	private void setDynamicArchivalResponseChildFour(JSONObject dynamicCaseResponseObj,
			Map<String, List<CaseViewDetailsBean>> maps, CaseViewDetailsBean caseViewDetailsBean, String columnName,
			String parentJsonAttributeName) {
		JSONArray parentJsonArray = dynamicCaseResponseObj.optJSONArray(parentJsonAttributeName);
		if (parentJsonArray != null) {
			JSONObject parentJsonObject = parentJsonArray.optJSONObject(0);

			if (parentJsonObject.has(columnName) && CaseViewConstants.OBJECTSTR.equalsIgnoreCase(caseViewDetailsBean.getType().trim())) {//changed for sonar fixes
					String leafElementValue = parentJsonObject.optString(columnName);
					caseViewDetailsBean.setValue(leafElementValue);
				}
		}
		if(maps.containsKey(caseViewDetailsBean.getSectionName().trim()))
			maps.get(caseViewDetailsBean.getSectionName().trim()).add(caseViewDetailsBean);
		else {
			List<CaseViewDetailsBean> list=new ArrayList<>();
			list.add(caseViewDetailsBean);
			maps.put(caseViewDetailsBean.getSectionName().trim(),list);
		}
	}

	private void setDynamicArchivalResponseChildThree(Map<String, List<CaseViewDetailsBean>> maps,
			CaseViewDetailsBean caseViewDetailsBean, String columnName, JSONArray jsonAttributeArray) {
		for (int i = 0; i < jsonAttributeArray.length(); i++) {
			JSONObject jsonAttributeObject = jsonAttributeArray.optJSONObject(i);
			String leafElementValue = jsonAttributeObject.optString(columnName);
			CaseViewDetailsBean caseViewDeatilsColBean = new CaseViewDetailsBean();
			caseViewDeatilsColBean.setAttribute(caseViewDetailsBean.getAttribute());
			caseViewDeatilsColBean.setAttributeNumber(caseViewDetailsBean.getAttributeNumber());
			caseViewDeatilsColBean.setDisplayAttribute(caseViewDetailsBean.getDisplayAttribute());
			caseViewDeatilsColBean.setDomain(caseViewDetailsBean.getDomain());
			caseViewDeatilsColBean.setLogonId(caseViewDetailsBean.getLogonId());
			caseViewDeatilsColBean.setSectionName(caseViewDetailsBean.getSectionName());
			caseViewDeatilsColBean.setSectionNumber(caseViewDetailsBean.getSectionNumber());
			caseViewDeatilsColBean.setSource(caseViewDetailsBean.getSource());
			caseViewDeatilsColBean.setTableName(caseViewDetailsBean.getTableName());
			caseViewDeatilsColBean.setTimeAdded(caseViewDetailsBean.getTimeAdded());
			caseViewDeatilsColBean.setTimeUpdated(caseViewDetailsBean.getTimeUpdated());
			caseViewDeatilsColBean.setType(caseViewDetailsBean.getType());
			caseViewDeatilsColBean.setValue(leafElementValue);
			if(maps.containsKey(caseViewDeatilsColBean.getSectionName().trim()))
				maps.get(caseViewDeatilsColBean.getSectionName().trim()).add(caseViewDeatilsColBean);
			else {
				List<CaseViewDetailsBean> list=new ArrayList<>();
				list.add(caseViewDeatilsColBean);
				maps.put(caseViewDetailsBean.getSectionName().trim(),list);
			}
		}
	}

	private void setDynamicArchivalResponseChildTwo(Map<String, List<CaseViewDetailsBean>> maps,
			CaseViewDetailsBean caseViewDetailsBean, String columnName, JSONObject parentJsonObject) {
		String leafElementValue = parentJsonObject.optString(columnName);
		caseViewDetailsBean.setValue(formatData(leafElementValue));
		
		if(maps.containsKey(caseViewDetailsBean.getSectionName().trim()))
			maps.get(caseViewDetailsBean.getSectionName().trim()).add(caseViewDetailsBean);
		else {
			List<CaseViewDetailsBean> list=new ArrayList<>();
			list.add(caseViewDetailsBean);
			maps.put(caseViewDetailsBean.getSectionName().trim(),list);
		}
	}

	private void setDynamicArchivalResponseChildOne(Map<String, List<CaseViewDetailsBean>> maps,
			CaseViewDetailsBean caseViewDetailsBean, String columnName, JSONArray jsonAttributeArray) {
		JSONObject jsonAttributeObject = jsonAttributeArray.optJSONObject(0);
		String leafElementValue = jsonAttributeObject.optString(columnName);
		caseViewDetailsBean.setValue(formatData(leafElementValue));
		
		if(maps.containsKey(caseViewDetailsBean.getSectionName().trim()))
			maps.get(caseViewDetailsBean.getSectionName().trim()).add(caseViewDetailsBean);
		else {
			List<CaseViewDetailsBean> list=new ArrayList<>();
			list.add(caseViewDetailsBean);
			maps.put(caseViewDetailsBean.getSectionName().trim(),list);
		}
	}

	private String getSalesforceCloumnName(String columnName) {
		String column;//changed for sonar fixes
		if (columnName.contains(".")) {
			column = columnName.substring(columnName.indexOf('.') + 1);
		} else {
			column=columnName;
		}
		return column;
	}

	private String getCloumnName(String columnName) {
		String column;//changed for sonar fixes
		String columnNameReturn;
		if (columnName.contains(".")) {
			column = columnName.substring(columnName.indexOf('.') + 1);
		}else {
			column=columnName;
		}
		if (column.contains("__C") || column.contains("__c")) {
			columnNameReturn = column.substring(0, column.length() - 3);
		}else {
			columnNameReturn=column;
		}
		return columnNameReturn;
	}
	
	
	public String formatData(String inDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(CaseViewConstants.SF_TIMESTAMP_FORMAT);
		SimpleDateFormat dateFormat1 = new SimpleDateFormat(CaseViewConstants.TIMESTAMP_FORMAT);
		dateFormat.setLenient(false);
		try {
		 return dateFormat1.format(dateFormat.parse(inDate.trim()));			
        } catch (ParseException pe) { 
        	 if(inDate.equalsIgnoreCase(CaseViewConstants.TRUE))
        		 return CaseViewConstants.YES;
        	 else if(inDate.equalsIgnoreCase(CaseViewConstants.FALSE))
        		 return CaseViewConstants.NO;
        	 else
        		 return inDate;
        }   
		
    }
	//ENHC0127020 Added
	/*
	 * Retrieve the case details if lob is returned or else show error message.
	 */
	@Override
	public CaseViewResponse getCaseDetailsOnCaseSearch(InputFilterBean inputFilterBean, HttpServletRequest httpServletRequest) throws CaseViewException {
		inputFilterBean.setSource("S");
		
		inputFilterBean.setLob(getLobFromCaseNumber(inputFilterBean, httpServletRequest));
		log.debug("LOB returned: {}", inputFilterBean.getLob());
		if(Strings.isEmpty(inputFilterBean.getLob())) {
			log.error("Case not found or Not authorized to view Case");
			throw new CaseViewException("Case not found or Not Authorized to view Case");
		}
		return getCaseDetailsOnCaseNumber(inputFilterBean, httpServletRequest);
		
	}
/*
 * Used to check LOB For given case as in order to retrieve filters for the given case we need the lob,
 * So this method is used to retrieve the LOB.
 */
	private String getLobFromCaseNumber(InputFilterBean inputFilterBean, HttpServletRequest httpServletRequest) throws CaseViewException  {
		
		try {
		// Retrieval of SFDC cases
			String[] listOfSfSelector= {"CC_LOB__c","Type","Owner.Name"};
			List<String> selector = Arrays.asList(listOfSfSelector);
			InputWrapperBean wrapperBean = new InputWrapperBean();

			wrapperBean.setFilters(inputFilterBean);
			wrapperBean.getFilters().setSfObject("Case");
			wrapperBean.getFilters().setName("CASE.CASENUMBER");
			
			wrapperBean.setSelectors(selector);
			
			JSONObject jsonResponse=null;
			JSONObject jsonRequest;

			jsonRequest = createJSONRequest(wrapperBean, inputFilterBean.getSource());


			jsonResponse = callSFDCWebservice(jsonRequest, false);
			log.debug("Json response in getLobFromCaseNumber For S Source:{} ", jsonResponse);
			if(jsonResponse!= null) {
				
				return getLobFromSFDCResponse(jsonResponse, httpServletRequest);
			}
			else {
				//Archival logic 
				String[] listOfArchivalSelector = {"CASE.CC_LOB__c", "CASE.TYPE"};
				inputFilterBean.setSource("R");
				inputFilterBean.setSfObject(null);
				inputFilterBean.setOperator("=");
				inputFilterBean.setName("CASE.CASENUMBER");
				wrapperBean.setFilters(inputFilterBean);

				wrapperBean.setSelectors(Arrays.asList(listOfArchivalSelector));
				jsonRequest = createJSONRequest(wrapperBean, inputFilterBean.getSource());
				jsonResponse = callArchivalWebservice(jsonRequest, "CASE");
				log.debug("Json response in getLobFromCaseNumber For R Source:{} ", jsonResponse);
				return getLobFromArchivalResponse(jsonResponse, httpServletRequest);
			}
			

		} catch (JSONException e) {
			log.error("Exception  occured in getLobFromCaseNumber ::", e);
			throw new CaseViewException("Error occurred while fetching additional case details. Please Contact System Administrator");
		}
		catch (IOException e) {
			log.error("Exception  occured in getLobFromCaseNumber ::", e);
			if((("422")).equalsIgnoreCase(e.getMessage()))
			{
				throw new CaseViewException("Case Not Found");
			}
			else if("400".equalsIgnoreCase(e.getMessage())) {
				throw new CaseViewException("Error occurred while fetching case details. Please Check Case Number");
			}
			else {
				throw new CaseViewException("Error occurred while fetching case details. Please Contact System administrator");
			}
		}
		
	}
	/*
	 * Returns LOB for the Archived cases
	 */
	private String getLobFromArchivalResponse (JSONObject jsonResponse, HttpServletRequest httpServletRequest) throws JSONException, IOException{
		if(jsonResponse!=null) {
			CaseViewResponse response = mapper.readValue(jsonResponse.toString(), CaseViewResponse.class);
			if(("200").equals(response.getStatus())) {
				JSONObject object = jsonResponse.optJSONObject("result");
				JSONObject arr= object.optJSONArray("CASE_OBJ").getJSONObject(0);
				if(authorized(arr.optString("TYPE"), httpServletRequest))
				{
					return arr.optString("CC_LOB");
				}
				else return "";
			}
			else {
				return "";
			}
		}
		else {
			throw new IOException("422");
		}
		
	}
	/*
	 * Returns LOB from SFDC case if the user is authorized or not
	 * Return blank string if not authorized or there is problems in response
	 */
	private String getLobFromSFDCResponse (JSONObject jsonResponse, HttpServletRequest httpServletRequest) throws JSONException, IOException{
		CaseViewResponse response = mapper.readValue(jsonResponse.toString(), CaseViewResponse.class);

		if(("success").equalsIgnoreCase(response.getStatus())) {
			JSONArray dynamicResponse = jsonResponse.getJSONArray("Dynamiccaseresponse");
			JSONObject caseObj = dynamicResponse.getJSONObject(0);
			String type = caseObj.getString("Type");
			String lob = caseObj.getString("CC_LOB__c");

			if(authorized(type, httpServletRequest)) {
				return lob;
			}

			else {
				return "";
			}

		}
		else {
			return "";
		}
	}
	/*
	 * This method is used to check whether a user is authorized to view,
	 * the particular case or not.
	 */
	private boolean authorized(String type, HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		ArrayList<String> groupList =  (ArrayList<String>) session.getAttribute("groupList");
		Boolean authorizer;
		log.debug("grouplist:{}", groupList);
		
		if(groupList.contains(CaseViewConstants.LEGAL_ROLE)) {
			authorizer = true;
		}
		else if(groupList.contains(CaseViewConstants.ECO_DIESEL_ROLE)) { 
			
			if(("EcoDiesel").equalsIgnoreCase(type)) {
			 authorizer = true;
			}
			else {
				authorizer = false;
			}
				
			}
		else {
			if(("legal").equalsIgnoreCase(type)) {
				authorizer = false;
			}
			else {
				authorizer = true;
			}
		}
			
		return authorizer;
	}
	
	
	//ENHC0127020 Ended
	
}
