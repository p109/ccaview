package com.fca.salesforce.bean;


public class InputFilterBean {

	private String name;
	private String operator;
	private String value;
	private boolean isNumeric;
	private String sfObject;
	private String lob;
	private String source;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public boolean isNumeric() {
		return isNumeric;
	}
	public void setNumeric(boolean isNumeric) {
		this.isNumeric = isNumeric;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getSfObject() {
		return sfObject;
	}
	public void setSfObject(String sfObject) {
		this.sfObject = sfObject;
	}
	 
}
