package com.fca.salesforce.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Data {

	private String key;
	private String value;

	
	public Data(@JsonProperty("key") String key,@JsonProperty("value") String value) {
		this.key=key.trim();
		this.value=value.trim();
	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key.trim();
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key.trim();
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value.trim();
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value.trim();
	}


}
