package com.fca.salesforce.bean;


public class CaseViewDetailsBean{
	private String domain;
	private String source;
	private String attribute;
	private int sectionNumber;
	private int attributeNumber;
	private String sectionName;
	private String displayAttribute;
	private String logonId;
	private String timeUpdated;
	private String timeAdded;
	private String value;
	private String tableName;
	private String type;
	
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getAttribute() {
		return attribute;
	}
	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}
	public int getSectionNumber() {
		return sectionNumber;
	}
	public void setSectionNumber(int sectionNumber) {
		this.sectionNumber = sectionNumber;
	}
	public int getAttributeNumber() {
		return attributeNumber;
	}
	public void setAttributeNumber(int attributeNumber) {
		this.attributeNumber = attributeNumber;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	public String getDisplayAttribute() {
		return displayAttribute;
	}
	public void setDisplayAttribute(String displayAttribute) {
		this.displayAttribute = displayAttribute;
	}
	public String getLogonId() {
		return logonId;
	}
	public void setLogonId(String logonId) {
		this.logonId = logonId;
	}
	public String getTimeUpdated() {
		return timeUpdated;
	}
	public void setTimeUpdated(String timeUpdated) {
		this.timeUpdated = timeUpdated;
	}
	public String getTimeAdded() {
		return timeAdded;
	}
	public void setTimeAdded(String timeAdded) {
		this.timeAdded = timeAdded;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}
