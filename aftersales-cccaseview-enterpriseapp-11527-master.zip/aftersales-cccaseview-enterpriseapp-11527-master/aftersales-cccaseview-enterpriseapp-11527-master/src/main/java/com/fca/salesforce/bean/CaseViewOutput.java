package com.fca.salesforce.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fca.salesforce.constant.CaseViewConstants;


@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseViewOutput {
	private String lob = "";
	private String creatDate = "";
	private String status = "";
	private String subject = "";
	private String lastModifiedDate = "";
	private String vin = "";
	private String caseNumber = "";
	private String type = "";
	private String callerName = "";
	private String ecciCaseNumber = "";
	private String source = "";
	private String owner = "";
	
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getCreatDate() {
		return creatDate;
	}
	
	public void setCreatDate(String creatDate) {
		SimpleDateFormat salesForceSDF = new SimpleDateFormat(CaseViewConstants.SF_TIMESTAMP_FORMAT);
		SimpleDateFormat sdf = new SimpleDateFormat(CaseViewConstants.TIMESTAMP_FORMAT);
		try {
			this.creatDate = sdf.format(salesForceSDF.parse(creatDate));
		} catch (ParseException e) {
			try {
				this.creatDate = sdf.format(sdf.parse(creatDate));
			} catch (ParseException e1) {
				this.creatDate = creatDate;
			}
		}
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(String lastModifiedDate) {
		SimpleDateFormat salesForceSDF = new SimpleDateFormat(CaseViewConstants.SF_TIMESTAMP_FORMAT);
		SimpleDateFormat sdf = new SimpleDateFormat(CaseViewConstants.TIMESTAMP_FORMAT);
		try {
			this.lastModifiedDate = sdf.format(salesForceSDF.parse(lastModifiedDate));
		} catch (ParseException e) {
			try {
				this.lastModifiedDate = sdf.format(sdf.parse(lastModifiedDate));
			} catch (ParseException e1) {
				this.lastModifiedDate = lastModifiedDate;
			}
		}
	}
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public String getCaseNumber() {
		return caseNumber;
	}
	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCallerName() {
		return callerName;
	}
	public void setCallerName(String callerName) {
		this.callerName = callerName;
	}
	public String getEcciCaseNumber() {
		return ecciCaseNumber;
	}
	public void setEcciCaseNumber(String ecciCaseNumber) {
		this.ecciCaseNumber = ecciCaseNumber;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
}
