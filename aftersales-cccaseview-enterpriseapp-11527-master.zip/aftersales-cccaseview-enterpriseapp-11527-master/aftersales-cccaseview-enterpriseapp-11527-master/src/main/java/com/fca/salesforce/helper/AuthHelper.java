package com.fca.salesforce.helper;

import javax.servlet.http.HttpServletRequest;
import com.fca.salesforce.constant.CaseViewConstants;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.nimbusds.openid.connect.sdk.AuthenticationResponse;
import com.nimbusds.openid.connect.sdk.AuthenticationSuccessResponse;

/**
 * @author T3893SP
 *
 */
public final class AuthHelper {

    public static final String PRINCIPAL_SESSION_NAME = "principal";

    private AuthHelper() {
    }

    /**
     * @param request
     * @return
     */
    public static boolean isAuthenticated(HttpServletRequest request) {
        return request.getSession().getAttribute(PRINCIPAL_SESSION_NAME) != null;
    }

    /**
     * @param request
     * @return
     */
    public static AuthenticationResult getAuthSessionObject(
            HttpServletRequest request) {
        return (AuthenticationResult) request.getSession().getAttribute(
                PRINCIPAL_SESSION_NAME);
    }

    /**
     * @param httpRequest
     * @return
     */
    public static boolean containsAuthenticationData(
            HttpServletRequest httpRequest) {
        return "POST".equalsIgnoreCase(httpRequest.getMethod()) && (httpRequest.getParameterMap().containsKey(
                        CaseViewConstants.ERROR)
                        || httpRequest.getParameterMap().containsKey(
                        		CaseViewConstants.ID_TOKEN) || httpRequest
                        .getParameterMap().containsKey(CaseViewConstants.CODE));
    }

    /**
     * @param authResponse
     * @return
     */
    public static boolean isAuthenticationSuccessful(
            AuthenticationResponse authResponse) {
        return authResponse instanceof AuthenticationSuccessResponse;
    }
}
