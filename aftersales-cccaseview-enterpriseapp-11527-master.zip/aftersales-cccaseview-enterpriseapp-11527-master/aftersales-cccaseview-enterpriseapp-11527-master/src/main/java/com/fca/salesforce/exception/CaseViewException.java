package com.fca.salesforce.exception;

/**
 * Custom Exception class to handle exception Occured in Application.
 *
 */
public class CaseViewException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CaseViewException() {
		super();
	}

	public CaseViewException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public CaseViewException(String arg0) {
		super(arg0);
	}

	public CaseViewException(Throwable arg0) {
		super(arg0);
	}
}
