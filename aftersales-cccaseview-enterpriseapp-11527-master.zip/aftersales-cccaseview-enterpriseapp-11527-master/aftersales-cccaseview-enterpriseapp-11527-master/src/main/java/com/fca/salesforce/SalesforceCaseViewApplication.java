package com.fca.salesforce;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class SalesforceCaseViewApplication extends SpringBootServletInitializer{

	private static Logger log = LogManager.getLogger(SalesforceCaseViewApplication.class); 
	 @Override
	   protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
	      return application.sources(SalesforceCaseViewApplication.class);
	   }
	
	public static void main(String[] args) {
		log.info("SalesforceCaseViewApplication Application started....."); // Sonar FIx -- Ashish
		String azureEnviornment = System.getenv("SPRING_PROFILES_ACTIVE");
		log.info("azureEnviornment : {} ",azureEnviornment);
		System.setProperty("spring.profiles.active", azureEnviornment);
		SpringApplication.run(SalesforceCaseViewApplication.class, args);
		
	}
	   @Bean
	   public RestTemplate getRestTemplate() {
	      return new RestTemplate();
	   }
	
	
}
