package com.fca.salesforce.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.fca.salesforce.boot.CustomAuthorizationFilter;
import com.fca.salesforce.boot.CustomLogoutHandler;
/*
 * Added as part of AAD to ADFS Migration. STRY0480396
 * Created date 02/08/2022
*/

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	
	  
	@Autowired
	CaseViewConfigResources resourceConfig;
	
	@Autowired
	private CustomLogoutHandler logoutHandler;
	 
	@Override
    protected void configure(HttpSecurity http) throws Exception {
		http
		  .authorizeRequests()
		  .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
      	  .antMatchers("/oauth2/authorization/**","/api/jobDetails","/template/**","/api/**","/js/**","/fonts/**","/document/**", "/images/**","/css/**","/**")
		  .permitAll()
          .anyRequest()
          .authenticated()
          .and()
          .logout()
          .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
          .addLogoutHandler(logoutHandler) //for custom logout
          .clearAuthentication(true)
	      .and().csrf().disable()
	      .oauth2Login();
				
		http.addFilterBefore(customAuthorizationFilter(), AnonymousAuthenticationFilter.class );
	}
	
	private CustomAuthorizationFilter customAuthorizationFilter() 
    {
        return new CustomAuthorizationFilter(resourceConfig);
    }
	
}
