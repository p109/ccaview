/*
 * package com.fca.salesforce.boot;
 * 
 * import java.io.IOException; import java.io.Serializable; import
 * java.io.UnsupportedEncodingException; import java.net.InetSocketAddress;
 * import java.net.MalformedURLException; import java.net.Proxy; import
 * java.net.URI; import java.net.URISyntaxException; import java.net.URLEncoder;
 * import java.text.ParseException; import java.util.Date; import
 * java.util.HashMap; import java.util.Iterator; import java.util.Map; import
 * java.util.UUID; import java.util.concurrent.ExecutionException; import
 * java.util.concurrent.ExecutorService; import java.util.concurrent.Executors;
 * import java.util.concurrent.Future; import java.util.concurrent.TimeUnit;
 * 
 * import javax.naming.ServiceUnavailableException; import javax.servlet.Filter;
 * import javax.servlet.FilterChain; import javax.servlet.FilterConfig; import
 * javax.servlet.ServletException; import javax.servlet.ServletRequest; import
 * javax.servlet.ServletResponse; import javax.servlet.http.HttpServletRequest;
 * import javax.servlet.http.HttpServletResponse; import
 * javax.servlet.http.HttpSession;
 * 
 * import org.apache.commons.lang3.StringUtils; import
 * org.apache.logging.log4j.LogManager; import org.apache.logging.log4j.Logger;
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Component;
 * 
 * import com.fca.salesforce.constant.CaseViewConstants; import
 * com.fca.salesforce.exception.AuthorizationException; import
 * com.fca.salesforce.helper.AuthHelper; import
 * com.fca.salesforce.helper.CaseViewConfigResources; import
 * com.microsoft.aad.adal4j.AuthenticationContext; import
 * com.microsoft.aad.adal4j.AuthenticationException; import
 * com.microsoft.aad.adal4j.AuthenticationResult; import
 * com.microsoft.aad.adal4j.ClientCredential; import com.nimbusds.jwt.JWTParser;
 * import com.nimbusds.oauth2.sdk.AuthorizationCode; import
 * com.nimbusds.openid.connect.sdk.AuthenticationErrorResponse; import
 * com.nimbusds.openid.connect.sdk.AuthenticationResponse; import
 * com.nimbusds.openid.connect.sdk.AuthenticationResponseParser; import
 * com.nimbusds.openid.connect.sdk.AuthenticationSuccessResponse;
 * 
 * @Component public class AuthorizationFilter implements Filter {
 * 
 * @Autowired CaseViewConfigResources resourceConfig;
 * 
 * private static Logger logger = LogManager
 * .getLogger(AuthorizationFilter.class);
 * 
 * public static final String STATES = "states"; public static final String
 * STATE = "state"; public static final Integer STATE_TTL = 3600; public static
 * final String FAILED_TO_VALIDATE_MESSAGE =
 * "Failed to validate data received from Authorization service - "; private
 * String clientId = ""; private String clientSecret = ""; private String tenant
 * = ""; private String authority = ""; private static final String INSIDE =
 * "inside"; // Sonar FIx -- Ashish
 * 
 *//**
	 * (non-Javadoc) Filter to accept the request and get logged-in user information
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
/*
 * public void doFilter(ServletRequest request, ServletResponse response,
 * FilterChain chain) throws IOException, ServletException { final String
 * methodName="doFilter"; HttpServletRequest httpRequest = (HttpServletRequest)
 * request; logger.info(methodName,((HttpServletRequest)
 * request).getContextPath()); HttpServletResponse httpResponse =
 * (HttpServletResponse) response; try { String currentUri =
 * httpRequest.getRequestURL().toString(); if
 * (!"true".equals(resourceConfig.getProperty(CaseViewConstants.LOCALFLAG))) {
 * currentUri = currentUri.replace(CaseViewConstants.HTTP,
 * CaseViewConstants.HTTPS); } String queryStr = httpRequest.getQueryString();
 * String fullUrl = currentUri + (queryStr != null ?
 * CaseViewConstants.QUESTION_MARK + queryStr : CaseViewConstants.EMPTY); //
 * check if user has a AuthData in the session if
 * (!AuthHelper.isAuthenticated(httpRequest)) { if
 * (AuthHelper.containsAuthenticationData(httpRequest)) {
 * processAuthenticationData(httpRequest, currentUri, fullUrl); } else { // not
 * authenticated sendAuthRedirect(httpRequest, httpResponse); return; } }
 * isAuthDataExpiredCheck(httpRequest); } catch (AuthenticationException
 * authException) { logger.error(INSIDE+methodName,"AuthenticationException:" +
 * authException); // something went wrong (like expiration or revocation of
 * token) // we should invalidate AuthData stored in session and redirect // to
 * Authorization server removePrincipalFromSession(httpRequest);
 * sendAuthRedirect(httpRequest, httpResponse); return; } catch
 * (AuthorizationException exc) {
 * logger.error(INSIDE+methodName,"AuthorizationException:" + exc);
 * httpResponse.setStatus(500); request.setAttribute(CaseViewConstants.ERROR,
 * exc.getMessage());
 * request.getRequestDispatcher(CaseViewConstants.EMPTY).forward(request,
 * response); } catch (InterruptedException exc) {
 * logger.error(INSIDE+methodName,"InterruptedException:" + exc);
 * httpResponse.setStatus(500); request.setAttribute(CaseViewConstants.ERROR,
 * exc.getMessage());
 * request.getRequestDispatcher(CaseViewConstants.EMPTY).forward(request,
 * response); Thread.currentThread().interrupt(); } chain.doFilter(request,
 * response); }
 * 
 *//**
	 * @param httpRequest
	 * @throws AuthorizationException
	 * @throws InterruptedException
	 */
/*
 * private void isAuthDataExpiredCheck(HttpServletRequest httpRequest) throws
 * AuthorizationException { if (isAuthDataExpired(httpRequest)) {
 * updateAuthDataUsingRefreshToken(httpRequest); } }
 * 
 *//**
	 * To Check Auth Session Expired.
	 * 
	 * @param httpRequest
	 * @return
	 */
/*
 * private boolean isAuthDataExpired(HttpServletRequest httpRequest) {
 * AuthenticationResult authData = AuthHelper
 * .getAuthSessionObject(httpRequest); return
 * authData.getExpiresOnDate().before(new Date()) ?
 * CaseViewConstants.TRUEBOOLEAN : CaseViewConstants.FALSEBOOLEAN; }
 * 
 *//**
	 * TO refresh Auth token
	 * 
	 * @param httpRequest
	 * @throws Throwable
	 */
/*
 * private void updateAuthDataUsingRefreshToken(HttpServletRequest httpRequest)
 * throws AuthorizationException { AuthenticationResult authData =
 * getAccessTokenFromRefreshToken(AuthHelper
 * .getAuthSessionObject(httpRequest).getRefreshToken());
 * setSessionPrincipal(httpRequest, authData); }
 * 
 *//**
	 * 
	 * Processing Auth data and setting it in session
	 * 
	 * @param httpRequest
	 * @param currentUri
	 * @param fullUrl
	 * @throws AuthorizationException
	 * @throws InterruptedException
	 */
/*
 * private void processAuthenticationData(HttpServletRequest httpRequest, String
 * currentUri, String fullUrl) throws AuthorizationException,
 * InterruptedException { final String methodName="processAuthenticationData";
 * HashMap<String, String> params = new HashMap<>(); for (String key :
 * httpRequest.getParameterMap().keySet()) { params.put(key,
 * httpRequest.getParameterMap().get(key)[0]); } logger.info(methodName+
 * "params: " + params); // validate that state in response equals to state in
 * request try { StateData stateData = validateState(httpRequest.getSession(),
 * params.get(STATE));
 * 
 * AuthenticationResponse authResponse = AuthenticationResponseParser .parse(new
 * URI(fullUrl), params); if
 * (AuthHelper.isAuthenticationSuccessful(authResponse)) {
 * AuthenticationSuccessResponse oidcResponse = (AuthenticationSuccessResponse)
 * authResponse; // validate that OIDC Auth Response matches Code Flow (contains
 * // only // requested artifacts)
 * validateAuthRespMatchesCodeFlow(oidcResponse);
 * 
 * AuthenticationResult authData = getAccessToken(
 * oidcResponse.getAuthorizationCode(), currentUri); //
 * logger.info(methodName+"access Token: " + authData.getAccessToken());
 * logger.info(methodName+"access Token Type: " +
 * authData.getAccessTokenType()); logger.info(methodName+"Expire After  : " +
 * authData.getExpiresAfter()); logger.info(methodName+"Id token  : " +
 * authData.getIdToken()); logger.info(methodName+"Refresh  token  : " +
 * authData.getRefreshToken()); logger.info(methodName+"User Info : " +
 * authData.getUserInfo().getGivenName());
 * 
 * // validate nonce to prevent reply attacks (code maybe // substituted // to
 * one with broader access) validateNonce( stateData,
 * getClaimValueFromIdToken(authData.getIdToken(), "nonce"));
 * 
 * setSessionPrincipal(httpRequest, authData); } else {
 * AuthenticationErrorResponse oidcResponse = (AuthenticationErrorResponse)
 * authResponse; throw new AuthorizationException(String.format(
 * "Request for auth code failed: %s - %s", oidcResponse
 * .getErrorObject().getCode(), oidcResponse
 * .getErrorObject().getDescription())); } } catch
 * (com.nimbusds.oauth2.sdk.ParseException | URISyntaxException |
 * ServiceUnavailableException | ParseException e) {
 * logger.error(INSIDE+methodName,"Error occured" + "" + e); throw new
 * AuthorizationException(e.getCause()); } }
 * 
 *//**
	 * @param stateData
	 * @param nonce
	 * @throws AuthorizationException
	 */
/*
 * private void validateNonce(StateData stateData, String nonce) throws
 * AuthorizationException { if (StringUtils.isEmpty(nonce) ||
 * !nonce.equals(stateData.getNonce())) { throw new
 * AuthorizationException(FAILED_TO_VALIDATE_MESSAGE +
 * "could not validate nonce"); } }
 * 
 *//**
	 * @param idToken
	 * @param claimKey
	 * @return
	 * @throws ParseException
	 */
/*
 * private String getClaimValueFromIdToken(String idToken, String claimKey)
 * throws ParseException { return (String)
 * JWTParser.parse(idToken).getJWTClaimsSet() .getClaim(claimKey); }
 * 
 *//**
	 * Redirect to Authorization URL.
	 * 
	 * @param httpRequest
	 * @param httpResponse
	 * @throws IOException
	 */
/*
 * private void sendAuthRedirect(HttpServletRequest httpRequest,
 * HttpServletResponse httpResponse) throws IOException {
 * httpResponse.setStatus(302); // use state parameter to validate response from
 * Authorization server String state = UUID.randomUUID().toString(); // use
 * nonce parameter to validate idToken String nonce =
 * UUID.randomUUID().toString(); storeStateInSession(httpRequest.getSession(),
 * state, nonce); httpResponse.sendRedirect(getRedirectUrl(state, nonce)); }
 * 
 *//**
	 * make sure that state is stored in the session, delete it from session -
	 * should be used only once
	 *
	 * @param session
	 * @param state
	 * @throws Exception
	 */
/*
 * private StateData validateState(HttpSession session, String state) throws
 * AuthorizationException { if (StringUtils.isNotEmpty(state)) { StateData
 * stateDataInSession = removeStateFromSession(session, state); if
 * (stateDataInSession != null) { return stateDataInSession; } } throw new
 * AuthorizationException(FAILED_TO_VALIDATE_MESSAGE +
 * "could not validate state"); }
 * 
 *//**
	 * @param oidcResponse
	 * @throws AuthorizationException
	 */
/*
 * private void validateAuthRespMatchesCodeFlow( AuthenticationSuccessResponse
 * oidcResponse) throws AuthorizationException { if (oidcResponse.getIDToken()
 * != null || oidcResponse.getAccessToken() != null ||
 * oidcResponse.getAuthorizationCode() == null) { throw new
 * AuthorizationException(FAILED_TO_VALIDATE_MESSAGE +
 * "unexpected set of artifacts received"); } }
 * 
 *//**
	 * @param session
	 * @param state
	 * @return
	 */
/*
 * @SuppressWarnings("unchecked") private StateData
 * removeStateFromSession(HttpSession session, String state) { Map<String,
 * StateData> states = (Map<String, StateData>) session .getAttribute(STATES);
 * if (states != null) { eliminateExpiredStates(states); StateData stateData =
 * states.get(state); if (stateData != null) { states.remove(state); return
 * stateData; } } return null; }
 * 
 *//**
	 * @param session
	 * @param state
	 * @param nonce
	 */
/*
 * @SuppressWarnings("unchecked") private void storeStateInSession(HttpSession
 * session, String state, String nonce) { if (session.getAttribute(STATES) ==
 * null) { session.setAttribute(STATES, new HashMap<String, StateData>()); }
 * ((Map<String, StateData>) session.getAttribute(STATES)).put(state, new
 * StateData(nonce, new Date())); }
 * 
 *//**
	 * @param map
	 */
/*
 * private void eliminateExpiredStates(Map<String, StateData> map) {
 * Iterator<Map.Entry<String, StateData>> it = map.entrySet().iterator(); Date
 * currTime = new Date(); while (it.hasNext()) { Map.Entry<String, StateData>
 * entry = it.next(); long diffInSeconds = TimeUnit.MILLISECONDS
 * .toSeconds(currTime.getTime() -
 * entry.getValue().getExpirationDate().getTime()); if (diffInSeconds >
 * STATE_TTL) { it.remove(); } } }
 * 
 *//**
	 * @param refreshToken
	 * @return
	 * @throws AuthorizationException
	 * @throws InterruptedException
	 */
/*
 * private AuthenticationResult getAccessTokenFromRefreshToken( String
 * refreshToken) throws AuthorizationException{ final String
 * methodName="getAccessTokenFromRefreshToken"; AuthenticationContext context;
 * AuthenticationResult result = null; ExecutorService service = null; try {
 * service = Executors.newFixedThreadPool(1); context = new
 * AuthenticationContext(authority + tenant + "/", true, service);
 * Future<AuthenticationResult> future = context
 * .acquireTokenByRefreshToken(refreshToken, new ClientCredential(clientId,
 * clientSecret), null, null); result = future.get(); } catch
 * (ExecutionException | MalformedURLException e) {
 * logger.error(INSIDE+methodName,"Error occured" + e); throw new
 * AuthorizationException(e.getCause()); } catch (InterruptedException e) {
 * logger.error(INSIDE+methodName,"InterruptedException" + e);
 * Thread.currentThread().interrupt(); } finally { if (service != null) {
 * service.shutdown(); } } if (result == null) { try { throw new
 * ServiceUnavailableException( "authentication result was null"); } catch
 * (ServiceUnavailableException e) {
 * logger.error(INSIDE+methodName,"ServiceUnavailableException" + e); } } return
 * result; }
 * 
 *//**
	 * @param authorizationCode
	 * @param currentUri
	 * @return
	 * @throws AuthorizationException
	 * @throws InterruptedException
	 * @throws ServiceUnavailableException
	 */
/*
 * private AuthenticationResult getAccessToken( AuthorizationCode
 * authorizationCode, String currentUri) throws AuthorizationException,
 * InterruptedException, ServiceUnavailableException { final String
 * methodName="getAccessToken"; String authCode = authorizationCode.getValue();
 * ClientCredential credential = new ClientCredential(clientId, clientSecret);
 * AuthenticationContext context; AuthenticationResult result = null;
 * ExecutorService service = null; try { service =
 * Executors.newFixedThreadPool(1);
 * 
 * context = new AuthenticationContext(authority + tenant + "/", true, service);
 * 
 * if
 * (CaseViewConstants.TRUE.equals(resourceConfig.getProperty(CaseViewConstants.
 * LOCALFLAG))) { Proxy proxy = new Proxy(Proxy.Type.HTTP, new
 * InetSocketAddress( resourceConfig.getProperty(CaseViewConstants.LOCALPROXY),
 * Integer.parseInt(resourceConfig
 * .getProperty(CaseViewConstants.LOCALPROXYPORT)))); context.setProxy(proxy); }
 * Future<AuthenticationResult> future = context
 * .acquireTokenByAuthorizationCode(authCode, new URI( currentUri), credential,
 * null);
 * 
 * result = future.get(); } catch (ExecutionException | MalformedURLException |
 * URISyntaxException e) { logger.error(INSIDE+methodName,"Error occured::" +
 * e); throw new AuthorizationException(e.getCause()); } finally { if (service
 * != null) { service.shutdown(); } }
 * 
 * if (result == null) { throw new ServiceUnavailableException(
 * "authentication result was null"); } return result; }
 * 
 *//**
	 * @param httpRequest
	 * @param result
	 */
/*
 * private void setSessionPrincipal(HttpServletRequest httpRequest,
 * AuthenticationResult result) { httpRequest.getSession().setAttribute(
 * AuthHelper.PRINCIPAL_SESSION_NAME, result); }
 * 
 *//**
	 * @param httpRequest
	 */
/*
 * private void removePrincipalFromSession(HttpServletRequest httpRequest) {
 * httpRequest.getSession().removeAttribute( AuthHelper.PRINCIPAL_SESSION_NAME);
 * }
 * 
 *//**
	 * @param state
	 * @param nonce
	 * @return
	 * @throws UnsupportedEncodingException
	 */
/*
 * private String getRedirectUrl(String state, String nonce) throws
 * UnsupportedEncodingException { final String methodName="getRedirectUrl";
 * String redirectUrl = authority + this.tenant +
 * "/oauth2/authorize?response_type=code&response_mode=form_post&redirect_uri="
 * + URLEncoder.encode(resourceConfig.getProperty("redirect-url"), "UTF-8") +
 * "&client_id=" + clientId + "&resource=https%3a%2f%2fgraph.microsoft.com" +
 * "&state=" + state + "&nonce=" + nonce;
 * 
 * logger.info(INSIDE+methodName,"Redirect Url:" + redirectUrl); return
 * redirectUrl; }
 * 
 * 
 * 
 * public void init(FilterConfig config) throws ServletException { clientId =
 * resourceConfig.getProperty("client-id"); authority =
 * resourceConfig.getProperty("authority"); tenant =
 * resourceConfig.getProperty("tenant-id"); clientSecret =
 * resourceConfig.getProperty("client-secret");
 * 
 * }
 * 
 *//**
	* 
	*
	*/
/*
 * private static class StateData implements Serializable { private static final
 * long serialVersionUID = 1L; private String nonce; private Date
 * expirationDate;
 * 
 * public StateData(String nonce, Date expirationDate) { this.nonce = nonce;
 * this.expirationDate = expirationDate; }
 * 
 * public String getNonce() { return nonce; }
 * 
 * public Date getExpirationDate() { return expirationDate; } }
 *//**
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 *//*
		 * @Override public void destroy() { final String methodName="destroy";
		 * logger.info(INSIDE +methodName+" called"); } }
		 */
