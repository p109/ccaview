package com.fca.salesforce.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fca.salesforce.bean.AuthResults;
import com.fca.salesforce.constant.CaseViewConstants;
import com.fca.salesforce.helper.AuthHelper;
import com.fca.salesforce.helper.CaseViewConfigResources;
import com.fca.salesforce.service.AuthorizationService;
import com.nimbusds.jwt.JWTParser;

/**
 * 
 * To authorize the user.
 */
@Controller
public class AuthorizationController {

	//@Autowired
	//AuthorizationFilter authFilter;

	@Autowired
	private CaseViewConfigResources resourceConfig;

	@Autowired
	AuthorizationService authService;

	private static Logger logger = LogManager
			.getLogger(AuthorizationController.class);
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/home", method = { RequestMethod.POST,
			RequestMethod.GET })
	public String authorizeUser(Map<String, Object> model,Model mvcModel,
			HttpServletRequest httpRequest) {
		final String methodName="authorizeUser";
		logger.info("Inside "+methodName);
		List<String> groupList;
		Map<String, String> data;
		String userGivenName;
		String userSurname;
		String userEmailAddress;
		String userTid;
		HttpSession session = httpRequest.getSession();
//		AuthenticationResult result = (AuthenticationResult) session.getAttribute(AuthHelper.PRINCIPAL_SESSION_NAME);// Commented for ADFS changes STRY0480396
		AuthResults result = (AuthResults) session.getAttribute(AuthHelper.PRINCIPAL_SESSION_NAME);
		if (result == null) {
			model.put(CaseViewConstants.WEBMSG, new Exception(
					"AuthenticationResult not found in session."));
			return CaseViewConstants.ERROR;
		} else {
			try {
				//start changes for ADSF STRY0480396
				//data = authService.getCurrentUserDetails(result.getAccessToken());
				String token = result.getAccessToken();
				if(null!=token) {
					String firstname = (String) JWTParser.parse(token).getJWTClaimsSet().getClaim("given_name");
					String lastname = (String) JWTParser.parse(token).getJWTClaimsSet().getClaim("family_name");
					String email = (String) JWTParser.parse(token).getJWTClaimsSet().getClaim("email");
					String tid = (String) JWTParser.parse(token).getJWTClaimsSet().getClaim("sub");
					groupList = (List<String>) JWTParser.parse(token).getJWTClaimsSet().getClaim("group");
					logger.info("given_name" + firstname);
					logger.info("family_name" + lastname);
					logger.info("email" + email);
					logger.info("sub" + tid);
					
			
				userGivenName = firstname;
				userSurname = lastname;
				userEmailAddress = email;
				userTid = tid;
				logger.info(methodName+"NAME:" + userGivenName + " " + userSurname);
				session.setAttribute(CaseViewConstants.USERNAME, userGivenName + " " + userSurname);
				session.setAttribute(CaseViewConstants.EMAIL, userEmailAddress);
				session.setAttribute(CaseViewConstants.TID, userTid);
				//groupList = authService	.getMemberGroups(result.getAccessToken());//Commented for ADFS
				logger.info(methodName+"GROUPS: " + groupList);
				logger.info("GROUPS: " + groupList);
				groupList.replaceAll(x -> x.substring(4));
				logger.info("GROUPS Updated: " + groupList);
				
				//END changes for ADSF STRY0480396
				session.setAttribute(CaseViewConstants.GROUP_LIST, groupList);
				if (!checkGroups(session)) {
					logger.info(methodName,"Unauthorised User : User not part of any group & also not an admin.");
					model.put(CaseViewConstants.WEBMSG, CaseViewConstants.USERNOTAUTHORISED);
					model.put(CaseViewConstants.USERROLE,CaseViewConstants.NOT_AUTHORIZED);
	
					return CaseViewConstants.ERROR;
				} else {
					authService.insertOrUpdateUserRecord(userGivenName, userSurname, userEmailAddress, userTid);
				}
				}
			}catch (ParseException e1) {
				logger.error("Error Occured: " + e1);
			}
		}
		mvcModel.addAttribute("LegalRoleDisplay", resourceConfig.getProperty(CaseViewConstants.LEGAL_ROLE));
		return CaseViewConstants.INDEX;
	}

	/**
	 * To check whether the user belongs to any one of the authorized group
	 * 
	 * @param model
	 * @param session
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private boolean checkGroups(HttpSession session) {
		List<String> groupList;
		String userGroup =CaseViewConstants.EMPTY ;
		boolean isValidUser = false;
		groupList = (ArrayList<String>) session
				.getAttribute(CaseViewConstants.GROUP_LIST);
		String activeGroupListString = resourceConfig.getProperty(CaseViewConstants.ACTIVE_GROUPS);
		List<String> activeGroupList = Arrays.asList(activeGroupListString.split(","));
		
		String userRole = "";
		for (String group : activeGroupList) {
			if(groupList.contains(group)) {
				isValidUser = true;
				userGroup = group;
				break;
			}
		}
		if(!userGroup.equalsIgnoreCase(CaseViewConstants.EMPTY)) {
			session.setAttribute(CaseViewConstants.USERROLEDISPLAY, resourceConfig.getProperty(userGroup));//changed for sonar fixes
		}
		session.setAttribute(CaseViewConstants.USERROLE, userGroup);//changed for sonar fixes
		logger.info("User Role : {} ", userRole);
		return isValidUser;
	}

//	@RequestMapping("/logout")
//	@ResponseBody
//	public String logout(HttpServletRequest httpRequest,
//			HttpServletResponse httpResponse) throws AuthorizationException {
//		try {
//			String redirectUri = resourceConfig.getProperty("redirect-url");
//			String authority = resourceConfig.getProperty("authority");
//			String tenant = resourceConfig.getProperty("tenant-id");
//			if (httpRequest.getSession() != null) {
//				httpRequest.getSession().invalidate();
//			}
//			// Clearing all cookies
//			if (httpRequest.getCookies() != null) {
//				for (Cookie cookie : httpRequest.getCookies()) {
//					cookie.setMaxAge(0);
//				}
//			}
//			httpResponse.sendRedirect(authority + tenant
//					+ "/oauth2/logout?post_logout_redirect_uri=" + redirectUri);
//		} catch (IOException e) {
//			// Some error occurred
//			logger.error(String.format("Problem logging out ...%s", e));
//			throw new AuthorizationException(e); // Sonar FIx -- Ashish
//		}
//		return "Logging out of application.";
//	}
	
	@RequestMapping(value = "/")
	public ModelAndView getHomeScreen() {
		return new ModelAndView("redirect:/home");
	}

}
