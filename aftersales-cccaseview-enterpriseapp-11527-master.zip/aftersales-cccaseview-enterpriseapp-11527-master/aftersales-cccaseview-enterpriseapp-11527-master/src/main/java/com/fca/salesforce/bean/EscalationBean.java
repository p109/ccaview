package com.fca.salesforce.bean;

public class EscalationBean {

	private String escalatedTo;
	private String recordId;
	private String emailPartSpec;
	private String escComment;
	private String reasonForEsc;
	private String coreGroup;
	private String customerWaiting;
	private String unableToDuplicate;
	private String unableToDiagonize;
	private String unableToRepair;
	private String repeatRepair;
	private String queueName;
	private String partNumber;
	private String omcNumber;
	private String orderNumber;
	public String getEscalatedTo() {
		return escalatedTo;
	}
	public void setEscalatedTo() {
	this.escalatedTo="";
	if("012f1000000qgahAAA".equalsIgnoreCase(recordId)) {
		this.escalatedTo = "STAR";
	}
	if("012f1000000qgagAAA".equalsIgnoreCase(recordId)) {
			this.escalatedTo = "Part Specifying";
	}
	if("012f1000000qgafAAA".equalsIgnoreCase(recordId)) {
			this.escalatedTo = "Part Expediting";
	}
	}
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	public String getEmailPartSpec() {
		return emailPartSpec;
	}
	public void setEmailPartSpec(String emailPartSpec) {
		this.emailPartSpec = emailPartSpec;
	}
	public String getEscComment() {
		return escComment;
	}
	public void setEscComment(String escComment) {
		this.escComment = escComment;
	}
	public String getReasonForEsc() {
		return reasonForEsc;
	}
	public void setReasonForEsc(String reasonForEsc) {
		this.reasonForEsc = reasonForEsc;
	}
	public String getCoreGroup() {
		return coreGroup;
	}
	public void setCoreGroup(String coreGroup) {
		this.coreGroup = coreGroup;
	}
	public String getCustomerWaiting() {
		return customerWaiting;
	}
	public void setCustomerWaiting(String customerWaiting) {
		this.customerWaiting = customerWaiting;
	}
	public String getUnableToDuplicate() {
		return unableToDuplicate;
	}
	public void setUnableToDuplicate(String unableToDuplicate) {
		this.unableToDuplicate = unableToDuplicate;
	}
	public String getUnableToDiagonize() {
		return unableToDiagonize;
	}
	public void setUnableToDiagonize(String unableToDiagonize) {
		this.unableToDiagonize = unableToDiagonize;
	}
	public String getUnableToRepair() {
		return unableToRepair;
	}
	public void setUnableToRepair(String unableToRepair) {
		this.unableToRepair = unableToRepair;
	}
	public String getRepeatRepair() {
		return repeatRepair;
	}
	public void setRepeatRepair(String repeatRepair) {
		this.repeatRepair = repeatRepair;
	}
	public String getQueueName() {
		return queueName;
	}
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getOmcNumber() {
		return omcNumber;
	}
	public void setOmcNumber(String omcNumber) {
		this.omcNumber = omcNumber;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		setEscalatedTo();
		builder.append(emailPartSpec);
		builder.append("	");
		builder.append(escComment);
		builder.append("	");
		builder.append(reasonForEsc);
		if("012f1000000qgahAAA".equalsIgnoreCase(recordId)) {
			builder.append(" Core Group: ");
			builder.append(coreGroup);
			builder.append(", Customer Waiting: ");
			builder.append(customerWaiting);
			builder.append(", Unable to Duplicate: ");
			builder.append(unableToDuplicate);
			builder.append(", Unable to Diagnosis: ");
			builder.append(unableToDiagonize);
			builder.append(", Unable to Repair: ");
			builder.append(unableToRepair);
			builder.append(", Repeat Repair: ");
			builder.append(repeatRepair);
			builder.append(", Queue Name: ");
			builder.append(queueName);

		}
		if("012f1000000qgagAAA".equalsIgnoreCase(recordId)) {
			builder.append("Part #: ");
			builder.append(partNumber);
		}
		if("012f1000000qgafAAA".equalsIgnoreCase(recordId)) {
			builder.append("Part #: ");
			builder.append(partNumber);
			builder.append(", OMC#: ");
			builder.append(omcNumber);
			builder.append(", Order# ");
			builder.append(orderNumber);
		}

		return builder.toString();
	}
	
	

	
	
	
}
