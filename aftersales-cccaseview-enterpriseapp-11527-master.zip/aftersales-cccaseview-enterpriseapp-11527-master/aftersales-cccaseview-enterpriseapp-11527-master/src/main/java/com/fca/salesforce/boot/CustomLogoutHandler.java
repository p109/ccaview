package com.fca.salesforce.boot;

import java.io.IOException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.stereotype.Component;

import com.fca.salesforce.bean.AuthResults;
import com.fca.salesforce.helper.AuthHelper;

/*
 * Added as part of AAD to ADFS Migration. STRY0480396
 * Created date 02/08/2022
*/
@Component
public class CustomLogoutHandler implements LogoutHandler {

	private static Logger logger = LogManager.getLogger(CustomLogoutHandler.class);
	
	@Override
	public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
		try {
			
			
			logger.info("custom logout executed");
			
			String idToken = "";
			if (request.getSession() != null) {
				logger.info("invalidate session details");
				AuthResults results = (AuthResults) request.getSession().getAttribute(AuthHelper.PRINCIPAL_SESSION_NAME);
				if(results!=null)
				{
					idToken = results.getIdToken();
				}
				request.getSession().invalidate();
			}
			// Clearing all cookies
			if (request.getCookies() != null) {
				logger.info("Clearing all cookies");
				for (Cookie cookie : request.getCookies()) {
					cookie.setMaxAge(0);
				}
			}
			if(!"".equals("idToken")) {
				logger.info("redirecting with post logout redirect url");
				response.sendRedirect("https://fed04.fcagroup.com/adfs/oauth2/logout?id_token_hint=" + idToken);
			}else {
				logger.info("redirecting without post logout redirect url");
				response.sendRedirect("https://fed04.fcagroup.com/adfs/oauth2/logout");
			}
		} catch (IOException e) {
			logger.error("Error occured in logout Method "+ e);
		}
	}
}
