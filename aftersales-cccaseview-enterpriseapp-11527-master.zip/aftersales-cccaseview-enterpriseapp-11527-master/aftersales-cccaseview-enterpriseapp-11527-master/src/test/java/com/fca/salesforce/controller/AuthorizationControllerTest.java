package com.fca.salesforce.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.ui.Model;

import com.fca.salesforce.bean.AuthResults;
import com.fca.salesforce.constant.CaseViewConstants;
import com.fca.salesforce.helper.AuthHelper;
import com.fca.salesforce.helper.CaseViewConfigResources;
import com.fca.salesforce.service.AuthorizationService;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AuthorizationController.class, JWTClaimsSet.class})
public class AuthorizationControllerTest {

	@Mock
	public AuthorizationService authService;

	@Mock
	public CaseViewConfigResources resourceConfig;

	@Mock
	public HttpServletRequest httpRequest;

	@Mock
	public HttpSession session;

	@InjectMocks
	public AuthorizationController authorizationController;

	@Mock
	public Model model;

	@Mock
	public AuthResults authResults;
	
	/*
	 * @Mock public AuthResults resultMock;
	 * 
	 * @Mock public JWT jwt;
	 * 
	 * @Mock public JWTClaimsSet jwtClaimsSet;
	 */
	
	
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		MockitoAnnotations.initMocks(this);
		when(httpRequest.getSession()).thenReturn(session);
		when(session.getAttribute(AuthHelper.PRINCIPAL_SESSION_NAME)).thenReturn(authResults);
	}
	
	
	@Test
	public void testAuthorizer() throws Exception {
		Map<String, Object> modelMap = new HashMap<>();

	        when(httpRequest.getSession()).thenReturn(session);
		when(session.getAttribute(AuthHelper.PRINCIPAL_SESSION_NAME)).thenReturn(new AuthResults());
		when(session.getAttribute(CaseViewConstants.USERNAME)).thenReturn("username surname");
		when(session.getAttribute(CaseViewConstants.EMAIL)).thenReturn("emailaddress");
		when(session.getAttribute(CaseViewConstants.TID)).thenReturn("123456");
		when(authService.insertOrUpdateUserRecord(anyString(),anyString(),anyString(),anyString())).thenReturn(true);
		String result = authorizationController.authorizeUser(modelMap, model, httpRequest);		
		assertEquals(CaseViewConstants.INDEX, result);
		
		modelMap.put(CaseViewConstants.USERNAME, "username surname");
		modelMap.put(CaseViewConstants.EMAIL, "email");
		modelMap.put(CaseViewConstants.TID, "123456");
		
		assertEquals("username surname", modelMap.get(CaseViewConstants.USERNAME));
		assertEquals("email", modelMap.get(CaseViewConstants.EMAIL));
		assertEquals("123456", modelMap.get(CaseViewConstants.TID));
		verify(model).addAttribute("LegalRoleDisplay",resourceConfig.getProperty(CaseViewConstants.LEGAL_ROLE));
		
	}
	 
	@Test
	 public void authorizeUser_AuthenticationResultnotFound() {
		
		Map<String, Object> modelMap = new HashMap<>();
		when(httpRequest.getSession()).thenReturn(session);
		when(session.getAttribute(AuthHelper.PRINCIPAL_SESSION_NAME)).thenReturn(null);
		String result = authorizationController.authorizeUser(modelMap, model, httpRequest);
		modelMap.put(CaseViewConstants.WEBMSG, "AuthenticationResult not found in sesion");
		assertEquals(CaseViewConstants.ERROR, result);
		assertEquals("AuthenticationResult not found in sesion", modelMap.get(CaseViewConstants.WEBMSG));	
	}	
}
