package com.fca.salesforce.dao;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fca.salesforce.bean.UserBean;

public class AuthorizationDaoTest {
	
	@InjectMocks
	AuthorizationDao authorizationDaoTest;
	
    @Mock
	JdbcTemplate jdbcTemplate;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		MockitoAnnotations.initMocks(this);
	}


	@Test
	void insertOrUpdateUserRecordtest() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		UserBean ub = new UserBean();
		ub.setGivenName("givenName");
		ub.setSurname("surname");
		ub.setEmailAddress("emailAddress");
		
		Method method = AuthorizationDao.class.getDeclaredMethod("insertOrUpdateUserRecord", String.class, String.class, String.class, String.class);
		method.setAccessible(true);
		method.invoke(authorizationDaoTest, new Object[] {ub.getGivenName(), ub.getSurname(), ub.getEmailAddress(), "T1234AB"});
		
	}
	
	@Test
	void insertOrUpdateUserRecordtest1() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		UserBean ub = new UserBean();
		ub.setGivenName("givenName");
		ub.setSurname("surname");
		ub.setEmailAddress(null);
		
		Method method = AuthorizationDao.class.getDeclaredMethod("insertOrUpdateUserRecord", String.class, String.class, String.class, String.class);
		method.setAccessible(true);
		method.invoke(authorizationDaoTest, new Object[] {ub.getGivenName(), ub.getSurname(), ub.getEmailAddress(), "T1234AB"});
		
	}

	@Test
	void insertOrUpdateUserRecordtest2() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		UserBean ub = new UserBean();
		ub.setGivenName(null);
		ub.setSurname(null);
		ub.setEmailAddress(null);
		
		Method method = AuthorizationDao.class.getDeclaredMethod("insertOrUpdateUserRecord", String.class, String.class, String.class, String.class);
		method.setAccessible(true);
		method.invoke(authorizationDaoTest, new Object[] {ub.getGivenName(), ub.getSurname(), ub.getEmailAddress(), null});
		
	}

}
