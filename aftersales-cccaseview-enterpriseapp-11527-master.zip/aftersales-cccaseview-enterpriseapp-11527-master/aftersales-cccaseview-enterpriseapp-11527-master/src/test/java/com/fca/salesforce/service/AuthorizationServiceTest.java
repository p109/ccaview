package com.fca.salesforce.service;

import java.lang.reflect.InvocationTargetException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fca.salesforce.bean.UserBean;
import com.fca.salesforce.dao.AuthorizationDao;

public class AuthorizationServiceTest {
	
	@InjectMocks
	AuthorizationService authorizationService;

	@Mock
	AuthorizationDao authorizationDaoTest;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
		MockitoAnnotations.initMocks(this);
	}

	
	
	@Test
	void insertOrUpdateUserRecordtest() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		authorizationService.insertOrUpdateUserRecord("givenName", "surName", "emailAddress", "T1234AB");
	}
}
